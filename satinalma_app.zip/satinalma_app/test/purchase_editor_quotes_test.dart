import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:satin_alma_evrak/features/purchase_files/presentation/purchase_editor.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

void main() {
  setUpAll(() async {
    await initializeDateFormatting('tr_TR');
  });

  testWidgets('farkli firma teklifleri farkli toplamlara yansir', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1440, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final settings = OrganizationSettings.demo();
    final base = PurchaseFile.createFromSettings(settings);
    final item = PurchaseItem(
      id: 'item-1',
      name: 'Kablo',
      quantity: 10,
      unit: 'ADET',
    );
    final vendors = [
      base.vendors[0].copyWith(name: 'Firma 1'),
      base.vendors[1].copyWith(name: 'Firma 2'),
      base.vendors[2].copyWith(name: 'Firma 3'),
      base.vendors[3].copyWith(name: 'Firma 4'),
    ];

    final purchaseFile = base.copyWith(
      items: [item],
      vendors: vendors,
      quotes: const [],
    );

    await tester.pumpWidget(
      ProviderScope(
        child: MaterialApp(
          home: Scaffold(
            body: PurchaseEditor(
              initialValue: purchaseFile,
              settings: settings,
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    await tester.ensureVisible(find.text('Teklifler'));
    await tester.tap(find.text('Teklifler'));
    await tester.pumpAndSettle();

    Future<void> enter(String vendorId, String value) async {
      final key = ValueKey('quote-${item.id}-$vendorId');
      expect(find.byKey(key), findsOneWidget);
      await tester.enterText(find.byKey(key), value);
      await tester.pump();
    }

    await enter(vendorIdForPurchaseFile(purchaseFile.id, 1), '100');
    await enter(vendorIdForPurchaseFile(purchaseFile.id, 2), '200');
    await enter(vendorIdForPurchaseFile(purchaseFile.id, 3), '300');
    await enter(vendorIdForPurchaseFile(purchaseFile.id, 4), '400');

    expect(find.text('100'), findsOneWidget);
    expect(find.text('200'), findsOneWidget);
    expect(find.text('300'), findsOneWidget);
    expect(find.text('400'), findsOneWidget);

    await tester.ensureVisible(find.text('Muayene'));
    await tester.tap(find.text('Muayene'));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('inspection-seller-Firma 1')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('inspection-excluding-1000')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('inspection-including-1200')),
      findsOneWidget,
    );

    await tester.ensureVisible(find.text('Onay ve Hesap'));
    await tester.tap(find.text('Onay ve Hesap'));
    await tester.pumpAndSettle();

    expect(find.text('En düşük teklif'), findsWidgets);
    expect(find.textContaining('TL1.000,00'), findsAtLeastNWidgets(2));
    expect(find.textContaining('TL2.000,00'), findsOneWidget);
    expect(find.textContaining('TL3.000,00'), findsOneWidget);
    expect(find.textContaining('TL4.000,00'), findsOneWidget);
  });

  test('createFromSettings sabit ve benzersiz firma idleri uretir', () {
    final purchaseFile = PurchaseFile.createFromSettings(
      OrganizationSettings.demo(),
    );
    final ids = purchaseFile.vendors.map((vendor) => vendor.id).toList();

    expect(ids.toSet().length, ids.length);
    expect(
      ids,
      [
        '${purchaseFile.id}-vendor-1',
        '${purchaseFile.id}-vendor-2',
        '${purchaseFile.id}-vendor-3',
        '${purchaseFile.id}-vendor-4',
      ],
    );
  });
}
