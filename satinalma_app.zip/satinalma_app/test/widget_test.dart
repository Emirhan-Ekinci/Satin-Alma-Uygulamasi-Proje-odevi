import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/app/app.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/auth/data/auth_service.dart';
import 'package:satin_alma_evrak/features/auth/domain/app_user.dart';
import 'package:satin_alma_evrak/features/auth/presentation/login_screen.dart';
import 'package:satin_alma_evrak/features/purchase_files/application/purchase_providers.dart';

void main() {
  testWidgets('uygulama demo modunda dogrudan calisma ekranini acar', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1440, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          appConfigProvider.overrideWithValue(_demoConfig),
        ],
        child: const ProcurementApp(),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.byType(AppShell), findsOneWidget);
    expect(find.textContaining('Demo mod'), findsOneWidget);
    expect(find.byType(LoginScreen), findsNothing);
  });

  testWidgets('uygulama firebase modunda cikis yapmis kullaniciya giris ekrani gosterir', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(1440, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          appConfigProvider.overrideWithValue(_firebaseConfig),
          isDemoModeProvider.overrideWithValue(false),
          authServiceProvider.overrideWithValue(
            _StubAuthService(initialUser: null),
          ),
        ],
        child: const ProcurementApp(),
      ),
    );

    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    expect(find.byType(AppShell), findsNothing);
  });
}

const _demoConfig = AppConfig(
  firebaseApiKey: '',
  firebaseProjectId: '',
  firebaseMessagingSenderId: '',
  firebaseAuthDomain: '',
  firebaseStorageBucket: '',
  firebaseMeasurementId: '',
  firebaseWebAppId: '',
  firebaseWindowsAppId: '',
  firebaseAndroidAppId: '',
);

const _firebaseConfig = AppConfig(
  firebaseApiKey: 'api-key',
  firebaseProjectId: 'project-id',
  firebaseMessagingSenderId: 'sender-id',
  firebaseAuthDomain: 'project.firebaseapp.com',
  firebaseStorageBucket: 'project.firebasestorage.app',
  firebaseMeasurementId: '',
  firebaseWebAppId: 'web-app-id',
  firebaseWindowsAppId: 'windows-app-id',
  firebaseAndroidAppId: 'android-app-id',
);

class _StubAuthService implements AuthService {
  _StubAuthService({required AppUser? initialUser}) : _initialUser = initialUser;

  final AppUser? _initialUser;

  @override
  Stream<AppUser?> authStateChanges() => Stream.value(_initialUser);

  @override
  AppUser? get currentUser => _initialUser;

  @override
  Future<void> signIn({
    required String email,
    required String password,
  }) async {}

  @override
  Future<void> signUp({
    required String email,
    required String password,
  }) async {}

  @override
  Future<void> signOut() async {}
}
