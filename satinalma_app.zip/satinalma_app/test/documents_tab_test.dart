import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/purchase_files/presentation/purchase_editor.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

void main() {
  setUpAll(() async {
    await initializeDateFormatting('tr_TR');
  });

  testWidgets('belgeler sekmesi acilir ve bos durum gorunur', (tester) async {
    tester.view.physicalSize = const Size(1440, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final settings = OrganizationSettings.demo();
    final purchaseFile = PurchaseFile.createFromSettings(settings);

    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          appConfigProvider.overrideWithValue(AppConfig.fromEnvironment()),
        ],
        child: MaterialApp(
          home: Scaffold(
            body: PurchaseEditor(
              initialValue: purchaseFile,
              settings: settings,
            ),
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    await tester.ensureVisible(find.text('Belgeler'));
    await tester.tap(find.text('Belgeler'));
    await tester.pumpAndSettle();

    expect(find.text('Belge Üretimi'), findsOneWidget);
    expect(find.text('Henüz belge üretilmedi.'), findsOneWidget);
  });
}
