import 'package:flutter_test/flutter_test.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_calculations.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

void main() {
  group('purchase calculations', () {
    final settings = OrganizationSettings.demo();
    final item1 = PurchaseItem(
      id: 'item-1',
      name: 'Kablo',
      quantity: 10,
      unit: 'ADET',
    );
    final item2 = PurchaseItem(
      id: 'item-2',
      name: 'Lehim',
      quantity: 5,
      unit: 'MAKARA',
    );
    final vendor1 = Vendor.empty(slot: 1).copyWith(id: 'vendor-1', name: 'A');
    final vendor2 = Vendor.empty(slot: 2).copyWith(id: 'vendor-2', name: 'B');

    final purchaseFile = PurchaseFile.createFromSettings(settings).copyWith(
      items: [item1, item2],
      vendors: [vendor1, vendor2],
      quotes: [
        VendorQuote(
          id: 'q1',
          purchaseItemId: item1.id,
          vendorId: vendor1.id,
          unitPrice: 2,
        ),
        VendorQuote(
          id: 'q2',
          purchaseItemId: item2.id,
          vendorId: vendor1.id,
          unitPrice: 4,
        ),
        VendorQuote(
          id: 'q3',
          purchaseItemId: item1.id,
          vendorId: vendor2.id,
          unitPrice: 3,
        ),
      ],
    );

    test('vendorTotal sums line totals', () {
      expect(vendorTotal(purchaseFile, vendor1.id), 40);
      expect(vendorTotal(purchaseFile, vendor2.id), 30);
    });

    test('approximateCost averages only quoted vendors', () {
      expect(approximateCost(purchaseFile), 35);
      expect(lowestVendorTotal(purchaseFile), 30);
      expect(totalQuotedVendorCount(purchaseFile), 2);
    });

    test('inspection defaults follow the lowest quoted vendor', () {
      final inspection = resolvedInspectionDetails(purchaseFile);

      expect(lowestQuotedVendor(purchaseFile)?.id, vendor2.id);
      expect(inspection.sellerCompanyName, 'B');
      expect(inspection.invoiceAmountExcludingVat, 30);
      expect(inspection.invoiceAmountIncludingVat, 36);
    });
  });
}
