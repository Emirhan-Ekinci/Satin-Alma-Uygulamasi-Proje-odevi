import 'dart:typed_data';

import 'package:fake_cloud_firestore/fake_cloud_firestore.dart';
import 'package:firebase_auth_mocks/firebase_auth_mocks.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:satin_alma_evrak/features/auth/data/firebase_auth_service.dart';
import 'package:satin_alma_evrak/features/documents/data/document_file_store.dart';
import 'package:satin_alma_evrak/features/documents/data/firebase_document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/data/local_document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/firebase_purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/data/firebase_settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

void main() {
  test('firebase auth service signs in and signs out with email password', () async {
    final auth = MockFirebaseAuth(
      signedIn: false,
      mockUser: MockUser(
        uid: 'user-1',
        email: 'test@example.com',
        isAnonymous: false,
      ),
    );
    final service = FirebaseAuthService(auth: auth);

    final events = <String?>[];
    final subscription = service.authStateChanges().listen(
      (user) => events.add(user?.email),
    );

    expect(service.currentUser, isNull);

    await service.signIn(
      email: 'test@example.com',
      password: 'secret123',
    );
    await Future<void>.delayed(Duration.zero);

    expect(service.currentUser?.id, 'user-1');
    expect(service.currentUser?.email, 'test@example.com');

    await service.signOut();
    await Future<void>.delayed(Duration.zero);

    expect(events, contains('test@example.com'));
    expect(events.last, isNull);

    await subscription.cancel();
  });

  test('firebase settings repository creates defaults and persists updates', () async {
    final firestore = FakeFirebaseFirestore();
    final repository = FirebaseSettingsRepository(firestore: firestore, userId: 'user-1');

    final initial = await repository.getSettings();
    expect(initial.organizationName, isNotEmpty);

    final saved = initial.copyWith(
      organizationName: 'Test Kurumu',
    );
    await repository.saveSettings(saved);

    final reloaded = await repository.getSettings();
    expect(reloaded.organizationName, 'Test Kurumu');
  });

  test('firebase purchase file repository saves lists and deletes purchase files', () async {
    final firestore = FakeFirebaseFirestore();
    final repository = FirebasePurchaseFileRepository(firestore: firestore, userId: 'user-1');
    final settings = OrganizationSettings.demo();
    final created = await repository.createFromSettings(settings);

    expect(created.id, isNotEmpty);

    final item = PurchaseItem(
      id: 'item-1',
      name: 'Kablo',
      quantity: 12,
      unit: 'ADET',
    );
    final updated = created.copyWith(
      title: 'Kablo Alimi',
      items: [item],
      quotes: [
        VendorQuote.empty(
          purchaseItemId: item.id,
          vendorId: created.vendors.first.id,
        ).copyWith(unitPrice: 85),
      ],
    );

    await repository.save(updated);

    final files = await repository.fetchAll();
    expect(files, hasLength(1));
    expect(files.single.title, 'Kablo Alimi');
    expect(files.single.items.single.name, 'Kablo');
    expect(files.single.quotes.single.unitPrice, 85);

    await repository.delete(created.id);

    expect(await repository.fetchAll(), isEmpty);
  });

  test('firebase document generation service stores generated document metadata in firestore', () async {
    final firestore = FakeFirebaseFirestore();
    final settings = OrganizationSettings.demo();
    final purchaseFile = PurchaseFile.createFromSettings(settings);
    final generatedAt = DateTime(2026, 4, 28, 10, 30);
    final expectedDocuments = [
      GeneratedDocument(
        id: 'doc-1',
        purchaseFileId: purchaseFile.id,
        documentType: 'Satin Alma Evrak Paketi',
        format: 'xlsx',
        status: 'ready',
        fileName: 'paket.xlsx',
        downloadUrl: r'C:\exports\paket.xlsx',
        notes: 'hazir',
        createdAt: generatedAt,
      ),
    ];

    final service = FirebaseDocumentGenerationService(
      firestore: firestore,
      localGenerator: _FakeLocalDocumentGenerationService(expectedDocuments),
      userId: 'user-1',
    );

    final generated = await service.generateDocuments(
      purchaseFile: purchaseFile,
      settings: settings,
    );

    expect(generated, hasLength(1));
    expect(generated.single.fileName, 'paket.xlsx');

    final reloaded = await service.listDocuments(purchaseFile.id);
    expect(reloaded, hasLength(1));
    expect(reloaded.single.downloadUrl, r'C:\exports\paket.xlsx');
    expect(reloaded.single.createdAt, generatedAt);

    final snapshot = await firestore
        .collection('purchase_files')
        .doc(purchaseFile.id)
        .collection('document_exports')
        .doc('doc-1')
        .get();
    expect(snapshot.exists, isTrue);
  });
}

class _FakeLocalDocumentGenerationService extends LocalDocumentGenerationService {
  _FakeLocalDocumentGenerationService(this._documents)
    : super(fileStore: _NoopDocumentFileStore());

  final List<GeneratedDocument> _documents;

  @override
  Future<List<GeneratedDocument>> generateDocuments({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) async {
    return _documents;
  }
}

class _NoopDocumentFileStore implements DocumentFileStore {
  @override
  Future<StoredDocumentFile> writeBytes({
    required String folderName,
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    return const StoredDocumentFile(
      reference: null,
      note: 'noop',
    );
  }
}
