import 'dart:typed_data';

import 'package:excel/excel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:satin_alma_evrak/features/documents/data/document_file_store.dart';
import 'package:satin_alma_evrak/features/documents/data/local_document_generation_service.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'local generator produces one pdf package and one multi-sheet xlsx file',
    () async {
      final settings = OrganizationSettings.demo();
      final base = PurchaseFile.createFromSettings(settings);
      final item = PurchaseItem(
        id: 'item-1',
        name: 'Kablo',
        quantity: 10,
        unit: 'ADET',
      );

      final purchaseFile = base.copyWith(
        title: 'Test Satin Alma',
        documentNumber: '2026-01',
        economicCode: '13 1',
        items: [item],
        quotes: [
          VendorQuote.empty(
            purchaseItemId: item.id,
            vendorId: base.vendors[0].id,
          ).copyWith(unitPrice: 100),
          VendorQuote.empty(
            purchaseItemId: item.id,
            vendorId: base.vendors[1].id,
          ).copyWith(unitPrice: 120),
        ],
      );

      final store = _FakeDocumentFileStore();
      final generator = LocalDocumentGenerationService(fileStore: store);

      final documents = await generator.generateDocuments(
        purchaseFile: purchaseFile,
        settings: settings,
      );

      expect(documents, hasLength(2));
      expect(store.savedFiles, hasLength(2));
      expect(
        store.savedFiles
            .where((entry) => entry.fileName.endsWith('.pdf'))
            .length,
        1,
      );
      expect(
        store.savedFiles
            .where((entry) => entry.fileName.endsWith('.xlsx'))
            .length,
        1,
      );
      expect(store.savedFiles.every((entry) => entry.bytes.isNotEmpty), isTrue);

      final workbookBytes = store.savedFiles
          .singleWhere((entry) => entry.fileName.endsWith('.xlsx'))
          .bytes;
      final workbook = Excel.decodeBytes(workbookBytes);
      final overview = workbook['Sayfa1'];
      final approval = workbook['onay'];
      final approximate = workbook['YakMaliyet (2)'];
      final inspection = workbook['MuayeneRaporu'];
      final marketResearch = workbook['Piyasa Fiyat Araştırma_yeni'];
      final offerLetter = workbook['Teklif'];
      final priceRequest = workbook['FiyatSorma'];

      expect(
        workbook.tables.keys,
        containsAll([
          'Sayfa1',
          'onay',
          'YakMaliyet (2)',
          'Piyasa Fiyat Araştırma_yeni',
          'Teklif',
          'FiyatSorma',
          'MuayeneRaporu',
        ]),
      );
      expect(
        overview.cell(CellIndex.indexByString('O17')).value.toString(),
        'MAL ALIM ONAY BELGESİ',
      );
      expect(
        overview.cell(CellIndex.indexByString('B7')).value.toString(),
        'Kablo',
      );
      expect(
        overview.cell(CellIndex.indexByString('F7')).value.toString(),
        '100',
      );
      expect(
        overview.cell(CellIndex.indexByString('G7')).value.toString(),
        '120',
      );
      expect(
        overview.cell(CellIndex.indexByString('J7')).value.toString(),
        '100',
      );
      expect(
        overview.cell(CellIndex.indexByString('K7')).value.toString(),
        '120',
      );
      expect(overview.cell(CellIndex.indexByString('B8')).value, isNull);
      expect(
        overview.cell(CellIndex.indexByString('P29')).value.toString(),
        'Yok',
      );
      expect(
        overview.cell(CellIndex.indexByString('P38')).value.toString(),
        'Firma 1',
      );
      expect(
        approval.cell(CellIndex.indexByString('Q7')).value.toString(),
        contains('2026-01'),
      );
      expect(
        approval.cell(CellIndex.indexByString('Q20')).value.toString(),
        '13 1',
      );
      expect(
        approximate.cell(CellIndex.indexByString('G10')).value.toString(),
        '100',
      );
      expect(
        approximate.cell(CellIndex.indexByString('H10')).value.toString(),
        '1000',
      );
      expect(
        marketResearch.cell(CellIndex.indexByString('F37')).value.toString(),
        'Firma 1',
      );
      expect(
        marketResearch.cell(CellIndex.indexByString('S37')).value.toString(),
        '1000',
      );
      expect(
        inspection.cell(CellIndex.indexByString('E7')).value.toString(),
        'Kablo',
      );
      expect(
        inspection.cell(CellIndex.indexByString('M7')).value.toString(),
        '10 ADET',
      );
      expect(
        inspection.cell(CellIndex.indexByString('Y7')).value.toString(),
        'Firma 1',
      );
      expect(
        offerLetter.cell(CellIndex.indexByString('A13')).value.toString(),
        'Kablo',
      );
      expect(
        priceRequest.cell(CellIndex.indexByString('F23')).value.toString(),
        '100',
      );
    },
  );
}

class _FakeDocumentFileStore implements DocumentFileStore {
  final List<_SavedFile> savedFiles = [];

  @override
  Future<StoredDocumentFile> writeBytes({
    required String folderName,
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    savedFiles.add(
      _SavedFile(
        folderName: folderName,
        fileName: fileName,
        mimeType: mimeType,
        bytes: bytes,
      ),
    );

    return StoredDocumentFile(
      reference: '/tmp/$folderName/$fileName',
      note: 'ok',
    );
  }
}

class _SavedFile {
  const _SavedFile({
    required this.folderName,
    required this.fileName,
    required this.mimeType,
    required this.bytes,
  });

  final String folderName;
  final String fileName;
  final String mimeType;
  final Uint8List bytes;
}
