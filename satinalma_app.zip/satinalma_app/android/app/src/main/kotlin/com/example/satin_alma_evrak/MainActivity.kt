package com.example.satin_alma_evrak

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
