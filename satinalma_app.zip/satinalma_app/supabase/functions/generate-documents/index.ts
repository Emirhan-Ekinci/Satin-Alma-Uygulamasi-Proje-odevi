import { createClient } from "jsr:@supabase/supabase-js@2";

const DOCUMENT_TYPES = [
  "Mal Alım Onay Belgesi",
  "Yaklaşık Maliyet Cetveli",
  "Piyasa Fiyat Araştırması Tutanağı",
  "Teklif Mektubu",
  "Fiyat Sorma Yazısı",
  "Muayene Raporu",
];

Deno.serve(async (request) => {
  const url = Deno.env.get("SUPABASE_URL") ?? "";
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
  const authHeader = request.headers.get("Authorization") ?? "";

  const client = createClient(url, anonKey, {
    global: { headers: { Authorization: authHeader } },
  });

  const body = await request.json();
  const purchaseFile = body.purchase_file;

  if (!purchaseFile?.id) {
    return new Response(JSON.stringify({ error: "purchase_file.id zorunlu" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const documents = DOCUMENT_TYPES.flatMap((type) =>
    ["pdf", "xlsx"].map((format) => ({
      id: crypto.randomUUID(),
      purchase_file_id: purchaseFile.id,
      document_type: type,
      format,
      status: "queued",
      file_name: `${purchaseFile.title ?? "purchase"}_${type}_${format}.${format}`,
      download_url: null,
      notes:
        "Belge üretim omurgası hazır. PDF/XLSX render entegrasyonu bu fonksiyonda tamamlanacak.",
      created_at: new Date().toISOString(),
    })),
  );

  const { error } = await client.from("document_exports").upsert(documents);

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ documents }), {
    headers: { "Content-Type": "application/json" },
  });
});
