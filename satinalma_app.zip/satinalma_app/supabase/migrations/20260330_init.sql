create extension if not exists pgcrypto;

create table if not exists organization_settings (
  id text primary key,
  organization_name text not null,
  organization_address text not null default '',
  principal_name text not null default '',
  principal_title text not null default '',
  deputy_principal_name text not null default '',
  deputy_principal_title text not null default '',
  technical_manager_name text not null default '',
  technical_manager_title text not null default '',
  committee_members jsonb not null default '[]'::jsonb,
  inspection_members jsonb not null default '[]'::jsonb
);

create table if not exists purchase_files (
  id text primary key,
  title text not null,
  description text not null default '',
  document_number text not null default '',
  request_date timestamptz,
  offer_deadline timestamptz,
  approval_date timestamptz,
  economic_code text not null default '',
  notes text not null default '',
  approval_details jsonb not null default '{}'::jsonb,
  inspection_details jsonb not null default '{}'::jsonb,
  organization_snapshot jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists purchase_items (
  id text primary key,
  purchase_file_id text not null references purchase_files(id) on delete cascade,
  name text not null default '',
  quantity numeric not null default 0,
  unit text not null default '',
  sort_order integer not null default 0
);

create table if not exists vendors (
  id text primary key,
  purchase_file_id text not null references purchase_files(id) on delete cascade,
  slot integer not null,
  name text not null default '',
  contact_name text not null default '',
  contact_email text not null default '',
  contact_phone text not null default '',
  address text not null default ''
);

create table if not exists vendor_quotes (
  id text primary key,
  purchase_file_id text not null references purchase_files(id) on delete cascade,
  purchase_item_id text not null references purchase_items(id) on delete cascade,
  vendor_id text not null references vendors(id) on delete cascade,
  unit_price numeric
);

create table if not exists document_exports (
  id text primary key,
  purchase_file_id text not null references purchase_files(id) on delete cascade,
  document_type text not null,
  format text not null,
  status text not null,
  file_name text not null,
  download_url text,
  notes text not null default '',
  created_at timestamptz not null default now()
);

alter table organization_settings enable row level security;
alter table purchase_files enable row level security;
alter table purchase_items enable row level security;
alter table vendors enable row level security;
alter table vendor_quotes enable row level security;
alter table document_exports enable row level security;

create policy "authenticated users can manage organization settings"
on organization_settings
for all
to authenticated
using (true)
with check (true);

create policy "authenticated users can manage purchase files"
on purchase_files
for all
to authenticated
using (true)
with check (true);

create policy "authenticated users can manage purchase items"
on purchase_items
for all
to authenticated
using (true)
with check (true);

create policy "authenticated users can manage vendors"
on vendors
for all
to authenticated
using (true)
with check (true);

create policy "authenticated users can manage quotes"
on vendor_quotes
for all
to authenticated
using (true)
with check (true);

create policy "authenticated users can manage document exports"
on document_exports
for all
to authenticated
using (true)
with check (true);
