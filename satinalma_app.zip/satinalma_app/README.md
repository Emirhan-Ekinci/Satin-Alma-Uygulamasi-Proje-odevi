# Satin Alma Evrak

Flutter ile hazirlanmis `Windows + Web` odakli satin alma evrak uygulamasi.

## Kapsam

- Satin alma dosyasi listesi
- Genel bilgiler, urunler, firmalar, teklifler, onay ve muayene sekmeleri
- Yaklasik maliyet ve firma toplam hesaplari
- Kurum ayarlari ve komisyon bilgileri
- Firebase Auth + Cloud Firestore tabanli veri katmani
- Yerel PDF + Excel belge uretimi
- Firebase ayarlari yoksa demo mod destegi

## Calistirma

Firebase olmadan demo modunda:

```bash
flutter pub get
flutter run -d windows
```

Firebase ile Windows icin:

```bash
flutter pub get
flutter run -d windows ^
  --dart-define=FIREBASE_API_KEY=YOUR_API_KEY ^
  --dart-define=FIREBASE_PROJECT_ID=YOUR_PROJECT_ID ^
  --dart-define=FIREBASE_MESSAGING_SENDER_ID=YOUR_SENDER_ID ^
  --dart-define=FIREBASE_AUTH_DOMAIN=YOUR_PROJECT.firebaseapp.com ^
  --dart-define=FIREBASE_STORAGE_BUCKET=YOUR_PROJECT.firebasestorage.app ^
  --dart-define=FIREBASE_WINDOWS_APP_ID=YOUR_WINDOWS_APP_ID
```

Firebase ile Web icin:

```bash
flutter pub get
flutter run -d chrome ^
  --dart-define=FIREBASE_API_KEY=YOUR_API_KEY ^
  --dart-define=FIREBASE_PROJECT_ID=YOUR_PROJECT_ID ^
  --dart-define=FIREBASE_MESSAGING_SENDER_ID=YOUR_SENDER_ID ^
  --dart-define=FIREBASE_AUTH_DOMAIN=YOUR_PROJECT.firebaseapp.com ^
  --dart-define=FIREBASE_STORAGE_BUCKET=YOUR_PROJECT.firebasestorage.app ^
  --dart-define=FIREBASE_WEB_APP_ID=YOUR_WEB_APP_ID ^
  --dart-define=FIREBASE_MEASUREMENT_ID=YOUR_MEASUREMENT_ID
```

## Firebase Kurulumu

1. Firebase projesinde `Authentication > Sign-in method` altindan `Email/Password` girisini ac.
2. `Cloud Firestore` veritabanini olustur.
3. Uygulama icin Web ve Windows istemci kayitlarini olustur.
4. Firebase kimlik bilgilerini yukaridaki `dart-define` parametreleriyle ver.
5. Kimlik bilgileri eksikse uygulama otomatik olarak demo modunda acilir.

## Veri Yapisi

- `purchase_files`
  Her satin alma dosyasi tek Firestore belgesi olarak tutulur.
- `purchase_files/{purchaseFileId}/document_exports`
  Uretilen belge kayitlari belge bazli alt koleksiyonda tutulur.
- `organization_settings/default`
  Kurum ayarlari tek belge olarak tutulur.

## Notlar

- Belge dosyalari Firebase Storage'a yuklenmez; sadece metadata Firestore'a yazilir.
- Windows tarafinda belge ciktilari yerel dosya yoluna kaydedilir.
- Web tarafinda belge ciktilari tarayici indirme akisiyla uretilir.
- Demo modunda auth, veri ve belge listesi yerel sahte servislerle calisir.
