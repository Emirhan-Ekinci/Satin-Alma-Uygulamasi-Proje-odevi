import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/features/purchase_files/application/purchase_providers.dart';
import 'package:satin_alma_evrak/features/settings/data/settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';
import 'package:satin_alma_evrak/shared/widgets/section_card.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingsAsync = ref.watch(organizationSettingsProvider);

    return settingsAsync.when(
      data: (settings) => _SettingsForm(initialValue: settings),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) => Center(child: Text(error.toString())),
    );
  }
}

class _SettingsForm extends ConsumerStatefulWidget {
  const _SettingsForm({required this.initialValue});

  final OrganizationSettings initialValue;

  @override
  ConsumerState<_SettingsForm> createState() => _SettingsFormState();
}

class _SettingsFormState extends ConsumerState<_SettingsForm> {
  late OrganizationSettings _draft;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _draft = widget.initialValue;
  }

  @override
  void didUpdateWidget(covariant _SettingsForm oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialValue.id != widget.initialValue.id) {
      _draft = widget.initialValue;
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    await ref.read(settingsRepositoryProvider).saveSettings(_draft);
    ref.invalidate(organizationSettingsProvider);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kurum ayarları kaydedildi.')),
      );
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionCard(
            title: 'Kurum Bilgileri',
            trailing: FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: _saving
                  ? const SizedBox.square(
                      dimension: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: const Text('Kaydet'),
            ),
            child: Wrap(
              runSpacing: 16,
              spacing: 16,
              children: [
                _wideField(
                  label: 'Kurum adı',
                  initialValue: _draft.organizationName,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(organizationName: value),
                  ),
                ),
                _wideField(
                  label: 'Kurum adresi',
                  initialValue: _draft.organizationAddress,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(organizationAddress: value),
                  ),
                ),
                _wideField(
                  label: 'Müdür',
                  initialValue: _draft.principalName,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(principalName: value),
                  ),
                ),
                _wideField(
                  label: 'Müdür unvanı',
                  initialValue: _draft.principalTitle,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(principalTitle: value),
                  ),
                ),
                _wideField(
                  label: 'Müdür yardımcısı',
                  initialValue: _draft.deputyPrincipalName,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(deputyPrincipalName: value),
                  ),
                ),
                _wideField(
                  label: 'Müdür yardımcısı unvanı',
                  initialValue: _draft.deputyPrincipalTitle,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(deputyPrincipalTitle: value),
                  ),
                ),
                _wideField(
                  label: 'Teknik yetkili',
                  initialValue: _draft.technicalManagerName,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(technicalManagerName: value),
                  ),
                ),
                _wideField(
                  label: 'Teknik yetkili unvanı',
                  initialValue: _draft.technicalManagerTitle,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(technicalManagerTitle: value),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          SectionCard(
            title: 'Komisyon Üyeleri',
            child: Column(
              children: [
                for (var i = 0; i < _draft.committeeMembers.length; i++) ...[
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          initialValue: _draft.committeeMembers[i].role,
                          decoration: const InputDecoration(labelText: 'Rol'),
                          onChanged: (value) => setState(() {
                            final next = [..._draft.committeeMembers];
                            next[i] = next[i].copyWith(role: value);
                            _draft = _draft.copyWith(committeeMembers: next);
                          }),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          initialValue: _draft.committeeMembers[i].fullName,
                          decoration:
                              const InputDecoration(labelText: 'Adı soyadı'),
                          onChanged: (value) => setState(() {
                            final next = [..._draft.committeeMembers];
                            next[i] = next[i].copyWith(fullName: value);
                            _draft = _draft.copyWith(committeeMembers: next);
                          }),
                        ),
                      ),
                    ],
                  ),
                  if (i != _draft.committeeMembers.length - 1)
                    const SizedBox(height: 12),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),
          SectionCard(
            title: 'Muayene Heyeti',
            child: Column(
              children: [
                for (var i = 0; i < _draft.inspectionMembers.length; i++) ...[
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          initialValue: _draft.inspectionMembers[i].role,
                          decoration: const InputDecoration(labelText: 'Rol'),
                          onChanged: (value) => setState(() {
                            final next = [..._draft.inspectionMembers];
                            next[i] = next[i].copyWith(role: value);
                            _draft = _draft.copyWith(inspectionMembers: next);
                          }),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          initialValue: _draft.inspectionMembers[i].fullName,
                          decoration:
                              const InputDecoration(labelText: 'Adı soyadı'),
                          onChanged: (value) => setState(() {
                            final next = [..._draft.inspectionMembers];
                            next[i] = next[i].copyWith(fullName: value);
                            _draft = _draft.copyWith(inspectionMembers: next);
                          }),
                        ),
                      ),
                    ],
                  ),
                  if (i != _draft.inspectionMembers.length - 1)
                    const SizedBox(height: 12),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _wideField({
    required String label,
    required String initialValue,
    required ValueChanged<String> onChanged,
  }) {
    return SizedBox(
      width: 360,
      child: TextFormField(
        initialValue: initialValue,
        decoration: InputDecoration(labelText: label),
        onChanged: onChanged,
      ),
    );
  }
}
