class CommitteeMember {
  const CommitteeMember({
    required this.role,
    required this.fullName,
  });

  final String role;
  final String fullName;

  CommitteeMember copyWith({
    String? role,
    String? fullName,
  }) {
    return CommitteeMember(
      role: role ?? this.role,
      fullName: fullName ?? this.fullName,
    );
  }

  Map<String, dynamic> toJson() => {
        'role': role,
        'full_name': fullName,
      };

  factory CommitteeMember.fromJson(Map<String, dynamic> json) {
    return CommitteeMember(
      role: (json['role'] ?? '') as String,
      fullName: (json['full_name'] ?? '') as String,
    );
  }
}

class OrganizationSettings {
  const OrganizationSettings({
    required this.id,
    required this.organizationName,
    required this.organizationAddress,
    required this.principalName,
    required this.principalTitle,
    required this.deputyPrincipalName,
    required this.deputyPrincipalTitle,
    required this.technicalManagerName,
    required this.technicalManagerTitle,
    required this.committeeMembers,
    required this.inspectionMembers,
  });

  factory OrganizationSettings.demo() {
    return const OrganizationSettings(
      id: 'default-settings',
      organizationName: 'Odunpazarı Atatürk Mesleki ve Teknik Anadolu Lisesi',
      organizationAddress: 'Eskişehir / Odunpazarı',
      principalName: 'Osman Anıl',
      principalTitle: 'Müdür',
      deputyPrincipalName: 'Mustafa Gümüş',
      deputyPrincipalTitle: 'Müdür Yardımcısı',
      technicalManagerName: 'İzzet Öcal',
      technicalManagerTitle: 'Teknik Müdür Yardımcısı',
      committeeMembers: [
        CommitteeMember(role: 'Komisyon Başkanı', fullName: 'Mustafa Gümüş'),
        CommitteeMember(role: 'Üye', fullName: 'Yaşar Gürbüz Sarıbaş'),
        CommitteeMember(role: 'Üye', fullName: 'Fatih Mermer'),
      ],
      inspectionMembers: [
        CommitteeMember(role: 'Muayene Başkanı', fullName: 'İzzet Öcal'),
        CommitteeMember(role: 'Üye', fullName: 'Yaşar Gürbüz Sarıbaş'),
        CommitteeMember(role: 'Üye', fullName: 'Fatih Mermer'),
      ],
    );
  }

  final String id;
  final String organizationName;
  final String organizationAddress;
  final String principalName;
  final String principalTitle;
  final String deputyPrincipalName;
  final String deputyPrincipalTitle;
  final String technicalManagerName;
  final String technicalManagerTitle;
  final List<CommitteeMember> committeeMembers;
  final List<CommitteeMember> inspectionMembers;

  OrganizationSettings copyWith({
    String? id,
    String? organizationName,
    String? organizationAddress,
    String? principalName,
    String? principalTitle,
    String? deputyPrincipalName,
    String? deputyPrincipalTitle,
    String? technicalManagerName,
    String? technicalManagerTitle,
    List<CommitteeMember>? committeeMembers,
    List<CommitteeMember>? inspectionMembers,
  }) {
    return OrganizationSettings(
      id: id ?? this.id,
      organizationName: organizationName ?? this.organizationName,
      organizationAddress: organizationAddress ?? this.organizationAddress,
      principalName: principalName ?? this.principalName,
      principalTitle: principalTitle ?? this.principalTitle,
      deputyPrincipalName: deputyPrincipalName ?? this.deputyPrincipalName,
      deputyPrincipalTitle:
          deputyPrincipalTitle ?? this.deputyPrincipalTitle,
      technicalManagerName: technicalManagerName ?? this.technicalManagerName,
      technicalManagerTitle:
          technicalManagerTitle ?? this.technicalManagerTitle,
      committeeMembers: committeeMembers ?? this.committeeMembers,
      inspectionMembers: inspectionMembers ?? this.inspectionMembers,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'organization_name': organizationName,
        'organization_address': organizationAddress,
        'principal_name': principalName,
        'principal_title': principalTitle,
        'deputy_principal_name': deputyPrincipalName,
        'deputy_principal_title': deputyPrincipalTitle,
        'technical_manager_name': technicalManagerName,
        'technical_manager_title': technicalManagerTitle,
        'committee_members':
            committeeMembers.map((member) => member.toJson()).toList(),
        'inspection_members':
            inspectionMembers.map((member) => member.toJson()).toList(),
      };

  factory OrganizationSettings.fromJson(Map<String, dynamic> json) {
    final committee =
        (json['committee_members'] as List<dynamic>? ?? <dynamic>[])
            .map((member) => CommitteeMember.fromJson(
                  Map<String, dynamic>.from(member as Map),
                ))
            .toList();
    final inspection =
        (json['inspection_members'] as List<dynamic>? ?? <dynamic>[])
            .map((member) => CommitteeMember.fromJson(
                  Map<String, dynamic>.from(member as Map),
                ))
            .toList();
    return OrganizationSettings(
      id: (json['id'] ?? 'default-settings') as String,
      organizationName: (json['organization_name'] ?? '') as String,
      organizationAddress: (json['organization_address'] ?? '') as String,
      principalName: (json['principal_name'] ?? '') as String,
      principalTitle: (json['principal_title'] ?? '') as String,
      deputyPrincipalName: (json['deputy_principal_name'] ?? '') as String,
      deputyPrincipalTitle:
          (json['deputy_principal_title'] ?? '') as String,
      technicalManagerName:
          (json['technical_manager_name'] ?? '') as String,
      technicalManagerTitle:
          (json['technical_manager_title'] ?? '') as String,
      committeeMembers: committee,
      inspectionMembers: inspection,
    );
  }
}
