import 'package:satin_alma_evrak/features/settings/data/settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class DemoSettingsRepository implements SettingsRepository {
  DemoSettingsRepository._();

  static final DemoSettingsRepository instance = DemoSettingsRepository._();

  OrganizationSettings _settings = OrganizationSettings.demo();

  @override
  Future<OrganizationSettings> getSettings() async {
    return _settings;
  }

  @override
  Future<void> saveSettings(OrganizationSettings settings) async {
    _settings = settings;
  }
}
