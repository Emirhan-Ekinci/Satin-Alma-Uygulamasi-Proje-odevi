import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satin_alma_evrak/features/settings/data/settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class FirebaseSettingsRepository implements SettingsRepository {
  FirebaseSettingsRepository({FirebaseFirestore? firestore, required String userId})
    : _firestore = firestore ?? FirebaseFirestore.instance,
      _userId = userId;

  final FirebaseFirestore _firestore;
  final String _userId;

  DocumentReference<Map<String, dynamic>> get _settingsDoc =>
      _firestore.collection('users').doc(_userId.isEmpty ? 'default' : _userId).collection('settings').doc('organization');

  @override
  Future<OrganizationSettings> getSettings() async {
    final snapshot = await _settingsDoc.get();
    if (!snapshot.exists) {
      final defaults = OrganizationSettings.demo();
      await saveSettings(defaults);
      return defaults;
    }

    return OrganizationSettings.fromJson(
      Map<String, dynamic>.from(snapshot.data()!),
    );
  }

  @override
  Future<void> saveSettings(OrganizationSettings settings) {
    return _settingsDoc.set(settings.toJson());
  }
}
