import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/settings/data/demo_settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/data/firebase_settings_repository.dart';
import 'package:satin_alma_evrak/features/auth/application/auth_providers.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

abstract class SettingsRepository {
  Future<OrganizationSettings> getSettings();

  Future<void> saveSettings(OrganizationSettings settings);
}

final settingsRepositoryProvider = Provider<SettingsRepository>((ref) {
  final config = ref.watch(appConfigProvider);
  if (config.useFirebase) {
    final userId = ref.watch(currentUserIdProvider);
    return FirebaseSettingsRepository(
      userId: userId,
    );
  }
  return DemoSettingsRepository.instance;
});
