import 'package:satin_alma_evrak/features/settings/data/settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseSettingsRepository implements SettingsRepository {
  SupabaseClient get _client => Supabase.instance.client;

  @override
  Future<OrganizationSettings> getSettings() async {
    final response = await _client
        .from('organization_settings')
        .select()
        .limit(1)
        .maybeSingle();

    if (response == null) {
      final defaults = OrganizationSettings.demo();
      await saveSettings(defaults);
      return defaults;
    }

    return OrganizationSettings.fromJson(Map<String, dynamic>.from(response));
  }

  @override
  Future<void> saveSettings(OrganizationSettings settings) async {
    await _client.from('organization_settings').upsert(settings.toJson());
  }
}
