import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/auth/data/demo_auth_service.dart';
import 'package:satin_alma_evrak/features/auth/data/firebase_auth_service.dart';
import 'package:satin_alma_evrak/features/auth/domain/app_user.dart';

abstract class AuthService {
  Stream<AppUser?> authStateChanges();

  AppUser? get currentUser;

  Future<void> signIn({
    required String email,
    required String password,
  });

  Future<void> signUp({
    required String email,
    required String password,
  });

  Future<void> signOut();
}

final authServiceProvider = Provider<AuthService>((ref) {
  final config = ref.watch(appConfigProvider);
  if (config.useFirebase) {
    return FirebaseAuthService();
  }
  return DemoAuthService.instance;
});
