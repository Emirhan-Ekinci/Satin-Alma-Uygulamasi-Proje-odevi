import 'dart:async';

import 'package:satin_alma_evrak/features/auth/data/auth_service.dart';
import 'package:satin_alma_evrak/features/auth/domain/app_user.dart';

class DemoAuthService implements AuthService {
  DemoAuthService._();

  static final DemoAuthService instance = DemoAuthService._();

  final StreamController<AppUser?> _controller =
      StreamController<AppUser?>.broadcast();

  AppUser? _currentUser;

  @override
  Stream<AppUser?> authStateChanges() async* {
    yield _currentUser;
    yield* _controller.stream;
  }

  @override
  AppUser? get currentUser => _currentUser;

  @override
  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    if (email.trim().isEmpty || password.trim().isEmpty) {
      throw Exception('E-posta ve parola zorunludur.');
    }
    _currentUser = AppUser(
      id: 'demo-user',
      email: email.trim(),
    );
    _controller.add(_currentUser);
  }

  @override
  Future<void> signUp({
    required String email,
    required String password,
  }) async {
    return signIn(email: email, password: password);
  }

  @override
  Future<void> signOut() async {
    _currentUser = null;
    _controller.add(null);
  }
}
