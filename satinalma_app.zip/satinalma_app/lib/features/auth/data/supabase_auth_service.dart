import 'package:satin_alma_evrak/features/auth/data/auth_service.dart';
import 'package:satin_alma_evrak/features/auth/domain/app_user.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseAuthService implements AuthService {
  SupabaseClient get _client => Supabase.instance.client;

  @override
  Stream<AppUser?> authStateChanges() async* {
    yield currentUser;
    yield* _client.auth.onAuthStateChange.map((event) {
      final user = event.session?.user;
      if (user == null) {
        return null;
      }
      return AppUser(
        id: user.id,
        email: user.email ?? '',
      );
    });
  }

  @override
  AppUser? get currentUser {
    final user = _client.auth.currentUser;
    if (user == null) {
      return null;
    }
    return AppUser(
      id: user.id,
      email: user.email ?? '',
    );
  }

  @override
  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  @override
  Future<void> signUp({
    required String email,
    required String password,
  }) async {
    await _client.auth.signUp(
      email: email,
      password: password,
    );
  }

  @override
  Future<void> signOut() async {
    await _client.auth.signOut();
  }
}
