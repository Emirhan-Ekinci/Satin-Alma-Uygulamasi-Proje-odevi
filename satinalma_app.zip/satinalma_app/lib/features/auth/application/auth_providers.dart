import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/features/auth/data/auth_service.dart';
import 'package:satin_alma_evrak/features/auth/domain/app_user.dart';

final authStateProvider = StreamProvider<AppUser?>(
  (ref) => ref.watch(authServiceProvider).authStateChanges(),
);

final currentUserIdProvider = Provider<String>((ref) {
  final authState = ref.watch(authStateProvider);
  return authState.valueOrNull?.id ?? '';
});
