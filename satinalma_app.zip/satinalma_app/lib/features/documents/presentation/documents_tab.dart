import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:open_filex/open_filex.dart';
import 'package:satin_alma_evrak/core/utils/formatters.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/application/purchase_providers.dart';
import 'package:satin_alma_evrak/shared/widgets/section_card.dart';

class DocumentsTab extends ConsumerWidget {
  const DocumentsTab({
    super.key,
    required this.purchaseFileId,
    required this.onGenerate,
    required this.generating,
  });

  final String purchaseFileId;
  final Future<void> Function() onGenerate;
  final bool generating;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final documentsAsync = ref.watch(documentsProvider(purchaseFileId));
    final isDemoMode = ref.watch(isDemoModeProvider);

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        SectionCard(
          title: 'Belge Üretimi',
          trailing: FilledButton.icon(
            onPressed: generating ? null : onGenerate,
            icon: generating
                ? const SizedBox.square(
                    dimension: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.file_download_outlined),
            label: const Text('PDF + Excel Üret'),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final contentWidth = constraints.maxWidth.isFinite
                  ? constraints.maxWidth
                  : MediaQuery.sizeOf(context).width;
              final tileWidth = _tileWidthFor(contentWidth);

              return documentsAsync.when(
                data: (documents) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isDemoMode
                          ? 'Demo modunda belgeler doğrudan yerel diske yazılır.'
                          : 'Edge Function üzerinden belge üretimi ve depolama akışı çalışır.',
                    ),
                    const SizedBox(height: 20),
                    if (documents.isEmpty)
                      const Text('Henüz belge üretilmedi.')
                    else
                      Wrap(
                        runSpacing: 16,
                        spacing: 16,
                        children: documents
                            .map(
                              (document) => _DocumentTile(
                                document: document,
                                width: tileWidth,
                              ),
                            )
                            .toList(),
                      ),
                  ],
                ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, stackTrace) => Text(error.toString()),
              );
            },
          ),
        ),
      ],
    );
  }

  double _tileWidthFor(double availableWidth) {
    if (availableWidth >= 1400) {
      return 280;
    }
    if (availableWidth >= 980) {
      return 260;
    }
    if (availableWidth >= 720) {
      return (availableWidth - 16) / 2;
    }
    return availableWidth - 48;
  }
}

class _DocumentTile extends StatelessWidget {
  const _DocumentTile({
    required this.document,
    required this.width,
  });

  final GeneratedDocument document;
  final double width;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: width,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            document.documentType,
            style: theme.textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Chip(label: Text(document.format.toUpperCase())),
              const SizedBox(width: 8),
              Chip(label: Text(document.status)),
            ],
          ),
          const SizedBox(height: 10),
          SelectableText(
            document.fileName,
            maxLines: 3,
          ),
          const SizedBox(height: 6),
          Text(
            'Oluşturma: ${formatDate(document.createdAt)}',
            style: theme.textTheme.bodySmall,
          ),
          if (document.notes.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              document.notes,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          if (document.downloadUrl != null) ...[
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => OpenFilex.open(document.downloadUrl!),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Aç'),
            ),
          ],
        ],
      ),
    );
  }
}
