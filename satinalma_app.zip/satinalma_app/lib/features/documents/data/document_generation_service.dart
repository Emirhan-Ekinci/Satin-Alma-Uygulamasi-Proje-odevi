import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/auth/application/auth_providers.dart';
import 'package:satin_alma_evrak/features/documents/data/demo_document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/data/firebase_document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

abstract class DocumentGenerationService {
  Future<List<GeneratedDocument>> listDocuments(String purchaseFileId);

  Future<List<GeneratedDocument>> generateDocuments({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  });
}

final documentGenerationServiceProvider =
    Provider<DocumentGenerationService>((ref) {
  final config = ref.watch(appConfigProvider);
  if (config.useFirebase) {
    final userId = ref.watch(currentUserIdProvider);
    return FirebaseDocumentGenerationService(
      userId: userId,
    );
  }
  return DemoDocumentGenerationService.instance;
});
