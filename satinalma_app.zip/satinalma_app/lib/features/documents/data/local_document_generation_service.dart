import 'package:excel/excel.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:satin_alma_evrak/features/documents/data/document_file_store.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_calculations.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class LocalDocumentGenerationService {
  LocalDocumentGenerationService({DocumentFileStore? fileStore})
    : _fileStore = fileStore ?? createDocumentFileStore();

  final DocumentFileStore _fileStore;

  static final NumberFormat _currencyFormatter = NumberFormat.currency(
    locale: 'tr_TR',
    symbol: 'TL',
    decimalDigits: 2,
  );
  static const String _templateAssetPath =
      'assets/templates/purchase_template.xlsx';
  static const int _templateItemStartRow = 7;
  static const int _templateItemEndRow = 94;
  static const int _approximateItemStartRow = 10;
  static const int _approximateItemEndRow = 34;
  static const int _marketResearchItemStartRow = 9;
  static const int _marketResearchItemEndRow = 33;
  static const int _marketResearchDecisionStartRow = 37;
  static const int _marketResearchDecisionEndRow = 61;
  static const int _offerLetterItemStartRow = 13;
  static const int _offerLetterItemEndRow = 34;
  static const int _priceRequestItemStartRow = 23;
  static const int _priceRequestItemEndRow = 50;

  Future<List<GeneratedDocument>> generateDocuments({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) async {
    final resolvedPurchaseFile = purchaseFile.copyWith(
      inspectionDetails: resolvedInspectionDetails(purchaseFile),
    );
    final now = DateTime.now();
    final bundleName =
        '${_safeSegment(resolvedPurchaseFile.title)}_${DateFormat('yyyyMMdd_HHmmss').format(now)}';
    final fonts = await _PdfFontBundle.load();
    final blueprints = _buildBlueprints(
      purchaseFile: resolvedPurchaseFile,
      settings: settings,
      generatedAt: now,
    );
    final documents = <GeneratedDocument>[];

    final pdfBytes = await _buildPdfPackage(blueprints, fonts);
    final pdfFileName =
        '${_safeSegment(resolvedPurchaseFile.title)}_evrak_paketi.pdf';
    final pdfStored = await _fileStore.writeBytes(
      folderName: bundleName,
      fileName: pdfFileName,
      bytes: pdfBytes,
      mimeType: 'application/pdf',
    );

    documents.add(
      GeneratedDocument(
        id: newId('doc'),
        purchaseFileId: resolvedPurchaseFile.id,
        documentType: 'Satın Alma Evrak Paketi',
        format: 'pdf',
        status: 'ready',
        fileName: pdfFileName,
        downloadUrl: pdfStored.reference,
        notes:
            '${blueprints.length} bölümlü tek PDF dosyası. ${pdfStored.note}',
      createdAt: now,
      ),
    );

    final workbookBytes = await _buildWorkbook(
      purchaseFile: resolvedPurchaseFile,
      settings: settings,
    );
    final workbookFileName =
        '${_safeSegment(resolvedPurchaseFile.title)}_evrak_paketi.xlsx';
    final workbookStored = await _fileStore.writeBytes(
      folderName: bundleName,
      fileName: workbookFileName,
      bytes: workbookBytes,
      mimeType:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );

    documents.add(
      GeneratedDocument(
        id: newId('doc'),
        purchaseFileId: resolvedPurchaseFile.id,
        documentType: 'Satın Alma Evrak Paketi',
        format: 'xlsx',
        status: 'ready',
        fileName: workbookFileName,
        downloadUrl: workbookStored.reference,
        notes:
            '${blueprints.length} sayfalı tek Excel dosyası. ${workbookStored.note}',
        createdAt: now,
      ),
    );

    return documents;
  }

  Future<Uint8List> _buildPdfPackage(
    List<_DocumentBlueprint> blueprints,
    _PdfFontBundle fonts,
  ) async {
    final document = pw.Document(
      theme: pw.ThemeData.withFont(base: fonts.regular, bold: fonts.bold),
    );

    for (final blueprint in blueprints) {
      document.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(32),
          build: (context) => [
            pw.Text(
              blueprint.title,
              style: pw.TextStyle(font: fonts.bold, fontSize: 20),
            ),
            pw.SizedBox(height: 6),
            pw.Text(
              blueprint.subtitle,
              style: const pw.TextStyle(fontSize: 10),
            ),
            pw.SizedBox(height: 18),
            for (final paragraph in blueprint.paragraphs) ...[
              pw.Text(paragraph),
              pw.SizedBox(height: 8),
            ],
            for (final section in blueprint.keyValueSections) ...[
              pw.SizedBox(height: blueprint.paragraphs.isEmpty ? 0 : 6),
              pw.Text(
                section.title,
                style: pw.TextStyle(font: fonts.bold, fontSize: 13),
              ),
              pw.SizedBox(height: 8),
              pw.TableHelper.fromTextArray(
                headers: const ['Alan', 'Değer'],
                data: [
                  for (final entry in section.entries) [entry.key, entry.value],
                ],
                headerStyle: pw.TextStyle(font: fonts.bold, fontSize: 10),
                cellStyle: const pw.TextStyle(fontSize: 10),
                headerDecoration: const pw.BoxDecoration(
                  color: PdfColors.grey300,
                ),
                cellAlignment: pw.Alignment.centerLeft,
                cellPadding: const pw.EdgeInsets.all(6),
              ),
              pw.SizedBox(height: 14),
            ],
            for (final table in blueprint.tables) ...[
              pw.Text(
                table.title,
                style: pw.TextStyle(font: fonts.bold, fontSize: 13),
              ),
              pw.SizedBox(height: 8),
              pw.TableHelper.fromTextArray(
                headers: table.headers,
                data: table.rows,
                headerStyle: pw.TextStyle(font: fonts.bold, fontSize: 10),
                cellStyle: const pw.TextStyle(fontSize: 9),
                headerDecoration: const pw.BoxDecoration(
                  color: PdfColors.grey300,
                ),
                cellPadding: const pw.EdgeInsets.all(6),
              ),
              pw.SizedBox(height: 14),
            ],
            pw.Divider(),
            pw.Text(blueprint.footer, style: const pw.TextStyle(fontSize: 9)),
          ],
        ),
      );
    }

    return document.save();
  }

  Future<Uint8List> _buildWorkbook({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) async {
    final templateData = await rootBundle.load(_templateAssetPath);
    final templateBytes = templateData.buffer.asUint8List();
    final excel = Excel.decodeBytes(templateBytes);

    _populateTemplateOverviewSheet(
      excel['Sayfa1'],
      purchaseFile: purchaseFile,
      settings: settings,
    );
    _populateApprovalSheet(
      excel['onay'],
      purchaseFile: purchaseFile,
      settings: settings,
    );
    _populateApproximateCostSheet(
      excel['YakMaliyet (2)'],
      purchaseFile: purchaseFile,
    );
    _populateMarketResearchSheet(
      excel['Piyasa Fiyat Araştırma_yeni'],
      purchaseFile: purchaseFile,
      settings: settings,
    );
    _populateInspectionSheet(
      excel['MuayeneRaporu'],
      purchaseFile: purchaseFile,
      settings: settings,
    );
    _populateOfferLetterSheet(excel['Teklif'], purchaseFile: purchaseFile);
    _populatePriceRequestSheet(
      excel['FiyatSorma'],
      purchaseFile: purchaseFile,
      settings: settings,
    );

    final bytes = excel.save();
    return Uint8List.fromList(bytes ?? templateBytes);
  }

  void _populateTemplateOverviewSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) {
    final effectiveRequestDate =
        purchaseFile.requestDate ?? purchaseFile.approvalDate ?? DateTime.now();
    final effectiveOfferDeadline =
        purchaseFile.offerDeadline ??
        effectiveRequestDate.add(const Duration(days: 1));
    final deadlineGap = effectiveOfferDeadline
        .difference(
          DateTime(
            effectiveRequestDate.year,
            effectiveRequestDate.month,
            effectiveRequestDate.day,
          ),
        )
        .inDays;
    final itemCountText = purchaseFile.items.isEmpty
        ? ''
        : '${purchaseFile.items.length} kalem';
    final preferredAmount = _preferredBudgetAmount(purchaseFile);

    _setDate(sheet, 'B2', effectiveRequestDate);
    _setFormula(sheet, 'B3', '=B2');
    _setDate(sheet, 'B4', effectiveOfferDeadline);
    _setNumber(sheet, 'D4', deadlineGap < 0 ? 0 : deadlineGap);
    _setFormula(sheet, 'B5', '=B4+D4');

    _setText(sheet, 'O5', settings.principalTitle);
    _setText(sheet, 'P5', settings.principalName);
    _setText(sheet, 'O6', settings.technicalManagerTitle);
    _setText(sheet, 'P6', settings.technicalManagerName);
    _setText(sheet, 'O7', _memberRole(settings.committeeMembers, 1));
    _setText(sheet, 'P7', _memberName(settings.committeeMembers, 1));
    _setText(sheet, 'O8', _memberRole(settings.committeeMembers, 2));
    _setText(sheet, 'P8', _memberName(settings.committeeMembers, 2));
    _setText(sheet, 'O10', _memberRole(settings.committeeMembers, 0));
    _setText(sheet, 'P10', _memberName(settings.committeeMembers, 0));
    _setText(sheet, 'O11', _memberRole(settings.inspectionMembers, 0));
    _setText(sheet, 'P11', _memberName(settings.inspectionMembers, 0));
    _setText(sheet, 'O12', _memberRole(settings.inspectionMembers, 1));
    _setText(sheet, 'P12', _memberName(settings.inspectionMembers, 1));
    _setText(sheet, 'O13', _memberRole(settings.inspectionMembers, 2));
    _setText(sheet, 'P13', _memberName(settings.inspectionMembers, 2));
    _setText(sheet, 'O14', settings.deputyPrincipalTitle);
    _setText(sheet, 'P14', settings.deputyPrincipalName);

    _setText(sheet, 'F6', _vendorName(purchaseFile, 0));
    _setText(sheet, 'G6', _vendorName(purchaseFile, 1));
    _setText(sheet, 'H6', _vendorName(purchaseFile, 2));
    _setText(sheet, 'I6', _vendorName(purchaseFile, 3));
    _setFormula(sheet, 'J6', '=F6');
    _setFormula(sheet, 'K6', '=G6');
    _setFormula(sheet, 'L6', '=H6');
    _setFormula(sheet, 'M6', '=I6');

    _setDate(sheet, 'P18', purchaseFile.approvalDate ?? effectiveRequestDate);
    _setText(sheet, 'P19', purchaseFile.documentNumber);
    _setText(
      sheet,
      'P20',
      _firstNonEmpty([
        purchaseFile.approvalDetails.workName,
        purchaseFile.title,
      ]),
    );
    _setText(
      sheet,
      'P21',
      _firstNonEmpty([
        purchaseFile.approvalDetails.workNature,
        purchaseFile.description,
      ]),
    );
    _setText(sheet, 'P22', itemCountText);
    _setNumber(sheet, 'P23', preferredAmount);
    _setText(
      sheet,
      'P24',
      _firstNonEmpty([purchaseFile.approvalDetails.fundSource, 'Yok']),
    );
    _setText(
      sheet,
      'P25',
      _firstNonEmpty([
        purchaseFile.approvalDetails.budgetCode,
        purchaseFile.economicCode,
      ]),
    );
    _setText(
      sheet,
      'P26',
      _firstNonEmpty([
        purchaseFile.approvalDetails.paymentTerms,
        'Verilmeyecek',
      ]),
    );
    _setText(
      sheet,
      'P27',
      _firstNonEmpty([
        purchaseFile.approvalDetails.procurementMethod,
        '4734/22-d',
      ]),
    );
    _setText(
      sheet,
      'P28',
      _firstNonEmpty([
        purchaseFile.approvalDetails.announcementTerms,
        'Ilan Verilmeyecek',
      ]),
    );
    _setText(sheet, 'P29', 'Yok');
    _setText(
      sheet,
      'P30',
      _firstNonEmpty([
        purchaseFile.approvalDetails.warrantyTerms,
        'Ödenmeyecek',
      ]),
    );
    _setText(
      sheet,
      'P31',
      _firstNonEmpty([
        purchaseFile.approvalDetails.additionalNotes,
        purchaseFile.notes,
        purchaseFile.approvalDetails.marketResearchText,
        purchaseFile.approvalDetails.workDescription,
        purchaseFile.description,
      ]),
    );
    _setDate(
      sheet,
      'P34',
      purchaseFile.inspectionDetails.invoiceDate ??
          purchaseFile.inspectionDetails.dispatchDate ??
          effectiveRequestDate,
    );
    _setNumber(sheet, 'P36', purchaseFile.inspectionDetails.stampTaxRate);
    _setText(sheet, 'P38', _preferredSellerCompanyName(purchaseFile));
    _setText(sheet, 'P39', purchaseFile.inspectionDetails.paymentOrderNumber);
    _setFormula(sheet, 'P40', '=P38');

    for (var row = _templateItemStartRow; row <= _templateItemEndRow; row++) {
      final itemIndex = row - _templateItemStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        _setNumber(sheet, 'A$row', itemIndex + 1);
        _setText(sheet, 'B$row', item.name);
        _setNumber(sheet, 'C$row', item.quantity);
        _setText(sheet, 'D$row', item.unit);
        _setFormula(sheet, 'E$row', '=CONCATENATE(C$row," ",D$row)');

        for (var vendorIndex = 0; vendorIndex < 4; vendorIndex++) {
          final vendor = _vendorAt(purchaseFile, vendorIndex);
          final quote = vendor == null
              ? null
              : quoteFor(
                  purchaseFile: purchaseFile,
                  itemId: item.id,
                  vendorId: vendor.id,
                )?.unitPrice;
          _setNumber(sheet, '${_columnLetter(6 + vendorIndex)}$row', quote);
          _setNumber(sheet, '${_columnLetter(10 + vendorIndex)}$row', quote);
        }
      } else {
        _clearCell(sheet, 'A$row');
        _clearCell(sheet, 'B$row');
        _clearCell(sheet, 'C$row');
        _clearCell(sheet, 'D$row');
        _clearCell(sheet, 'E$row');
        for (var vendorIndex = 0; vendorIndex < 8; vendorIndex++) {
          _clearCell(sheet, '${_columnLetter(6 + vendorIndex)}$row');
        }
      }
    }
  }

  void _populateApprovalSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) {
    final effectiveApprovalDate =
        purchaseFile.approvalDate ??
        purchaseFile.requestDate ??
        DateTime.now();
    final itemCountText = purchaseFile.items.isEmpty
        ? ''
        : '${purchaseFile.items.length} kalem';
    final workName = _firstNonEmpty([
      purchaseFile.approvalDetails.workName,
      purchaseFile.title,
    ]);
    final workNature = _firstNonEmpty([
      purchaseFile.approvalDetails.workNature,
      purchaseFile.description,
    ]);
    final additionalDescription = _firstNonEmpty([
      purchaseFile.approvalDetails.additionalNotes,
      purchaseFile.notes,
      purchaseFile.approvalDetails.marketResearchText,
      purchaseFile.approvalDetails.workDescription,
      purchaseFile.description,
    ]);
    final documentReference = purchaseFile.documentNumber.trim();
    final documentHeader = documentReference.isEmpty
        ? _dateOrDash(effectiveApprovalDate)
        : '${_dateOrDash(effectiveApprovalDate)} - $documentReference';

    _setText(sheet, 'Q5', settings.organizationName);
    _setText(sheet, 'Q7', documentHeader);
    _setText(sheet, 'K12', workName);
    _setText(sheet, 'K13', workNature);
    _setText(sheet, 'K14', itemCountText);
    _setNumber(sheet, 'Q17', approximateCost(purchaseFile));
    _setNumber(sheet, 'Q18', _preferredBudgetAmount(purchaseFile));
    _setText(
      sheet,
      'Q19',
      _firstNonEmpty([purchaseFile.approvalDetails.fundSource, 'Yok']),
    );
    _setText(
      sheet,
      'Q20',
      _firstNonEmpty([
        purchaseFile.approvalDetails.budgetCode,
        purchaseFile.economicCode,
      ]),
    );
    _setText(
      sheet,
      'Q21',
      _firstNonEmpty([
        purchaseFile.approvalDetails.paymentTerms,
        'Verilmeyecek',
      ]),
    );
    _setText(
      sheet,
      'Q22',
      _firstNonEmpty([
        purchaseFile.approvalDetails.procurementMethod,
        '4734/22-d',
      ]),
    );
    _setText(
      sheet,
      'Q23',
      _firstNonEmpty([
        purchaseFile.approvalDetails.announcementTerms,
        'Ilan Verilmeyecek',
      ]),
    );
    _setText(sheet, 'Q24', 'Yok');
    _setText(sheet, 'Q25', 'Ödenmeyecek');
    _setText(sheet, 'Q26', additionalDescription);
    _setText(sheet, 'D29', additionalDescription);
    _setText(sheet, 'I46', settings.deputyPrincipalName);
    _setText(sheet, 'I47', settings.deputyPrincipalTitle);
    _setText(sheet, 'U44', settings.principalName);
    _setText(sheet, 'U45', settings.principalTitle);
  }

  void _populateInspectionSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) {
    const inspectionItemStartRow = 7;
    const inspectionItemEndRow = 31;
    final resolvedInspection = resolvedInspectionDetails(purchaseFile);
    final effectiveInspectionDate =
        resolvedInspection.dispatchDate ??
        resolvedInspection.invoiceDate ??
        purchaseFile.requestDate ??
        DateTime.now();
    final warehouseLocation = _firstNonEmpty([
      resolvedInspection.warehouseLocation,
      'Okul Ambarı',
    ]);

    for (var row = inspectionItemStartRow; row <= inspectionItemEndRow; row++) {
      final itemIndex = row - inspectionItemStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        _setNumber(sheet, 'C$row', itemIndex + 1);
        _setText(sheet, 'E$row', item.name);
        _setText(sheet, 'M$row', '${_quantityText(item.quantity)} ${item.unit}');
        _setDate(sheet, 'S$row', effectiveInspectionDate);
        _setText(sheet, 'Y$row', resolvedInspection.sellerCompanyName);
        _setText(sheet, 'AE$row', warehouseLocation);
      } else {
        for (final column in ['C', 'E', 'M', 'S', 'Y', 'AE']) {
          _clearCell(sheet, '$column$row');
        }
      }
    }

    _setText(sheet, 'D54', _memberName(settings.inspectionMembers, 0));
    _setText(sheet, 'D55', _memberRole(settings.inspectionMembers, 0));
    _setText(sheet, 'O54', _memberName(settings.inspectionMembers, 1));
    _setText(sheet, 'O55', _memberRole(settings.inspectionMembers, 1));
    _setText(sheet, 'Z54', _memberName(settings.inspectionMembers, 2));
    _setText(sheet, 'Z55', _memberRole(settings.inspectionMembers, 2));
  }

  void _populateApproximateCostSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
  }) {
    _setText(sheet, 'G7', _vendorName(purchaseFile, 0));
    _setText(sheet, 'I7', _vendorName(purchaseFile, 1));
    _setText(sheet, 'K7', _vendorName(purchaseFile, 2));
    _setText(sheet, 'M7', _vendorName(purchaseFile, 3));

    for (
      var row = _approximateItemStartRow;
      row <= _approximateItemEndRow;
      row++
    ) {
      final itemIndex = row - _approximateItemStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        _setNumber(sheet, 'A$row', itemIndex + 1);
        _setText(sheet, 'B$row', item.name);
        _setNumber(sheet, 'E$row', item.quantity);
        _setText(sheet, 'F$row', item.unit);

        final prices = _itemPricesByVendor(purchaseFile, item);
        _setNumber(sheet, 'G$row', prices[0]);
        _setNumber(sheet, 'H$row', _lineTotal(item, prices[0]));
        _setNumber(sheet, 'I$row', prices[1]);
        _setNumber(sheet, 'J$row', _lineTotal(item, prices[1]));
        _setNumber(sheet, 'K$row', prices[2]);
        _setNumber(sheet, 'L$row', _lineTotal(item, prices[2]));
        _setNumber(sheet, 'M$row', prices[3]);
        _setNumber(sheet, 'N$row', _lineTotal(item, prices[3]));
      } else {
        for (final column in [
          'A',
          'B',
          'E',
          'F',
          'G',
          'H',
          'I',
          'J',
          'K',
          'L',
          'M',
          'N',
        ]) {
          _clearCell(sheet, '$column$row');
        }
      }
    }

    final totals = _vendorTotalsByIndex(purchaseFile);
    _setNumber(sheet, 'H35', totals[0]);
    _setNumber(sheet, 'J35', totals[1]);
    _setNumber(sheet, 'L35', totals[2]);
    _setNumber(sheet, 'N35', totals[3]);
    _setNumber(sheet, 'P35', _averageOfNonNull(totals));
  }

  void _populateMarketResearchSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) {
    final approvalDate =
        purchaseFile.approvalDate ??
        purchaseFile.requestDate ??
        DateTime.now();
    _setText(sheet, 'F2', ': ${settings.organizationName}');
    _setText(
      sheet,
      'F3',
      _firstNonEmpty([
        purchaseFile.approvalDetails.workDescription,
        purchaseFile.description,
        purchaseFile.title,
      ]),
    );
    _setText(sheet, 'F4', ':');
    _setDate(sheet, 'G4', approvalDate);
    _setText(sheet, 'I4', purchaseFile.documentNumber);
    _setText(sheet, 'H7', _vendorName(purchaseFile, 0));
    _setText(sheet, 'L7', _vendorName(purchaseFile, 1));
    _setText(sheet, 'P7', _vendorName(purchaseFile, 2));
    _setText(sheet, 'T7', _vendorName(purchaseFile, 3));

    for (
      var row = _marketResearchItemStartRow;
      row <= _marketResearchItemEndRow;
      row++
    ) {
      final itemIndex = row - _marketResearchItemStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        final prices = _itemPricesByVendor(purchaseFile, item);
        _setNumber(sheet, 'A$row', itemIndex + 1);
        _setText(sheet, 'B$row', item.name);
        _setNumber(sheet, 'F$row', item.quantity);
        _setText(sheet, 'G$row', item.unit);
        _setNumber(sheet, 'H$row', prices[0]);
        _setNumber(sheet, 'J$row', _lineTotal(item, prices[0]));
        _setNumber(sheet, 'L$row', prices[1]);
        _setNumber(sheet, 'N$row', _lineTotal(item, prices[1]));
        _setNumber(sheet, 'P$row', prices[2]);
        _setNumber(sheet, 'R$row', _lineTotal(item, prices[2]));
        _setNumber(sheet, 'T$row', prices[3]);
        _setNumber(sheet, 'V$row', _lineTotal(item, prices[3]));
      } else {
        for (final column in [
          'A',
          'B',
          'F',
          'G',
          'H',
          'J',
          'L',
          'N',
          'P',
          'R',
          'T',
          'V',
        ]) {
          _clearCell(sheet, '$column$row');
        }
      }
    }

    final totals = _vendorTotalsByIndex(purchaseFile);
    _setNumber(sheet, 'J34', totals[0]);
    _setNumber(sheet, 'N34', totals[1]);
    _setNumber(sheet, 'R34', totals[2]);
    _setNumber(sheet, 'V34', totals[3]);

    for (
      var row = _marketResearchDecisionStartRow;
      row <= _marketResearchDecisionEndRow;
      row++
    ) {
      final itemIndex = row - _marketResearchDecisionStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        final bestQuote = _bestQuoteForItem(purchaseFile, item);
        _setNumber(sheet, 'A$row', itemIndex + 1);
        _setText(sheet, 'B$row', item.name);
        _setText(sheet, 'F$row', bestQuote?.vendor.name);
        _setText(sheet, 'K$row', bestQuote?.vendor.address);
        _setNumber(sheet, 'S$row', bestQuote?.total);
      } else {
        for (final column in ['A', 'B', 'F', 'K', 'S']) {
          _clearCell(sheet, '$column$row');
        }
      }
    }
  }

  void _populateOfferLetterSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
  }) {
    final offerDate =
        purchaseFile.offerDeadline ??
        purchaseFile.requestDate ??
        DateTime.now();
    _setDate(sheet, 'I3', offerDate);

    for (
      var row = _offerLetterItemStartRow;
      row <= _offerLetterItemEndRow;
      row++
    ) {
      final itemIndex = row - _offerLetterItemStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        _setText(sheet, 'A$row', item.name);
        _setNumber(sheet, 'D$row', item.quantity);
        _setText(sheet, 'E$row', item.unit);
      } else {
        for (final column in ['A', 'D', 'E', 'F', 'H']) {
          _clearCell(sheet, '$column$row');
        }
      }
    }
  }

  void _populatePriceRequestSheet(
    Sheet sheet, {
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) {
    _setDate(sheet, 'G7', purchaseFile.requestDate ?? DateTime.now());
    _setText(sheet, 'F18', settings.principalName);
    _setText(sheet, 'F19', settings.principalTitle);

    for (
      var row = _priceRequestItemStartRow;
      row <= _priceRequestItemEndRow;
      row++
    ) {
      final itemIndex = row - _priceRequestItemStartRow;
      if (itemIndex < purchaseFile.items.length) {
        final item = purchaseFile.items[itemIndex];
        _setNumber(sheet, 'A$row', itemIndex + 1);
        _setText(sheet, 'B$row', item.name);
        _setText(
          sheet,
          'E$row',
          '${_quantityText(item.quantity)} ${item.unit}',
        );
        _setNumber(sheet, 'F$row', _lowestUnitPriceForItem(purchaseFile, item));
      } else {
        for (final column in ['A', 'B', 'E', 'F']) {
          _clearCell(sheet, '$column$row');
        }
      }
    }
  }

  List<double?> _itemPricesByVendor(
    PurchaseFile purchaseFile,
    PurchaseItem item,
  ) {
    return List<double?>.generate(4, (index) {
      final vendor = _vendorAt(purchaseFile, index);
      if (vendor == null) {
        return null;
      }
      return quoteFor(
        purchaseFile: purchaseFile,
        itemId: item.id,
        vendorId: vendor.id,
      )?.unitPrice;
    });
  }

  double? _lineTotal(PurchaseItem item, double? unitPrice) {
    if (unitPrice == null) {
      return null;
    }
    return item.quantity * unitPrice;
  }

  List<double?> _vendorTotalsByIndex(PurchaseFile purchaseFile) {
    return List<double?>.generate(4, (index) {
      final vendor = _vendorAt(purchaseFile, index);
      if (vendor == null || !vendorHasAnyQuote(purchaseFile, vendor.id)) {
        return null;
      }
      return vendorTotal(purchaseFile, vendor.id);
    });
  }

  double? _lowestUnitPriceForItem(
    PurchaseFile purchaseFile,
    PurchaseItem item,
  ) {
    final prices = _itemPricesByVendor(
      purchaseFile,
      item,
    ).whereType<double>().toList();
    if (prices.isEmpty) {
      return null;
    }
    prices.sort();
    return prices.first;
  }

  double? _averageOfNonNull(List<double?> values) {
    final present = values.whereType<double>().toList();
    if (present.isEmpty) {
      return null;
    }
    return present.reduce((sum, item) => sum + item) / present.length;
  }

  _BestQuote? _bestQuoteForItem(PurchaseFile purchaseFile, PurchaseItem item) {
    _BestQuote? bestQuote;
    for (var vendorIndex = 0; vendorIndex < 4; vendorIndex++) {
      final vendor = _vendorAt(purchaseFile, vendorIndex);
      if (vendor == null) {
        continue;
      }
      final unitPrice = quoteFor(
        purchaseFile: purchaseFile,
        itemId: item.id,
        vendorId: vendor.id,
      )?.unitPrice;
      if (unitPrice == null) {
        continue;
      }
      final total = item.quantity * unitPrice;
      if (bestQuote == null || total < bestQuote.total) {
        bestQuote = _BestQuote(
          vendor: vendor,
          unitPrice: unitPrice,
          total: total,
        );
      }
    }
    return bestQuote;
  }

  void _setText(Sheet sheet, String cell, String? value) {
    sheet.cell(CellIndex.indexByString(cell)).value = TextCellValue(
      (value ?? '').trim(),
    );
  }

  void _setFormula(Sheet sheet, String cell, String formula) {
    sheet.cell(CellIndex.indexByString(cell)).value = FormulaCellValue(formula);
  }

  void _setDate(Sheet sheet, String cell, DateTime? value) {
    if (value == null) {
      _clearCell(sheet, cell);
      return;
    }
    sheet.cell(CellIndex.indexByString(cell)).value =
        DateCellValue.fromDateTime(value);
  }

  void _setNumber(Sheet sheet, String cell, num? value) {
    if (value == null) {
      _clearCell(sheet, cell);
      return;
    }
    final normalized = value.toDouble();
    sheet
        .cell(CellIndex.indexByString(cell))
        .value = normalized == normalized.roundToDouble()
        ? IntCellValue(normalized.round())
        : DoubleCellValue(normalized);
  }

  void _clearCell(Sheet sheet, String cell) {
    sheet.cell(CellIndex.indexByString(cell)).value = null;
  }

  Vendor? _vendorAt(PurchaseFile purchaseFile, int index) {
    if (index < 0 || index >= purchaseFile.vendors.length) {
      return null;
    }
    return purchaseFile.vendors[index];
  }

  String _vendorName(PurchaseFile purchaseFile, int index) {
    final vendor = _vendorAt(purchaseFile, index);
    final value = vendor?.name.trim() ?? '';
    if (value.isNotEmpty) {
      return value;
    }
    return 'Firma ${index + 1}';
  }

  double _preferredBudgetAmount(PurchaseFile purchaseFile) {
    final lowest = lowestVendorTotal(purchaseFile);
    if (lowest > 0) {
      return lowest;
    }
    final average = approximateCost(purchaseFile);
    if (average > 0) {
      return average;
    }
    return purchaseFile.inspectionDetails.invoiceAmountExcludingVat ?? 0;
  }

  String _preferredSellerCompanyName(PurchaseFile purchaseFile) {
    final explicit = purchaseFile.inspectionDetails.sellerCompanyName.trim();
    if (explicit.isNotEmpty) {
      return explicit;
    }

    Vendor? selectedVendor;
    double? selectedTotal;

    for (final vendor in purchaseFile.vendors) {
      if (!vendorHasAnyQuote(purchaseFile, vendor.id)) {
        continue;
      }
      final total = vendorTotal(purchaseFile, vendor.id);
      if (selectedTotal == null || total < selectedTotal) {
        selectedTotal = total;
        selectedVendor = vendor;
      }
    }

    return selectedVendor?.name.trim() ?? '';
  }

  CommitteeMember? _memberAt(List<CommitteeMember> members, int index) {
    if (index < 0 || index >= members.length) {
      return null;
    }
    return members[index];
  }

  String _memberName(List<CommitteeMember> members, int index) {
    return _memberAt(members, index)?.fullName.trim() ?? '';
  }

  String _memberRole(List<CommitteeMember> members, int index) {
    return _memberAt(members, index)?.role.trim() ?? '';
  }

  String _firstNonEmpty(List<String?> values) {
    for (final value in values) {
      final trimmed = (value ?? '').trim();
      if (trimmed.isNotEmpty) {
        return trimmed;
      }
    }
    return '';
  }

  String _safeSegment(String raw) {
    final sanitized = raw
        .trim()
        .replaceAll(RegExp(r'[<>:"/\\|?*]+'), ' ')
        .replaceAll(RegExp(r'\s+'), '_');
    return sanitized.isEmpty ? 'belge' : sanitized.toLowerCase();
  }

  String _dateOrDash(DateTime? value) {
    if (value == null) {
      return '-';
    }
    final day = value.day.toString().padLeft(2, '0');
    final month = value.month.toString().padLeft(2, '0');
    return '$day.$month.${value.year}';
  }

  String _quantityText(double value) {
    if (value == value.roundToDouble()) {
      return value.toStringAsFixed(0);
    }
    return value.toStringAsFixed(2);
  }

  String _currencyOrDash(double? value) {
    if (value == null) {
      return '-';
    }
    return _currencyFormatter.format(value);
  }

  String _valueOrDash(String? value, {String? fallback}) {
    final resolved = (value ?? '').trim();
    if (resolved.isNotEmpty) {
      return resolved;
    }
    final backup = (fallback ?? '').trim();
    return backup.isNotEmpty ? backup : '-';
  }

  String _columnLetter(int oneBasedColumn) {
    var value = oneBasedColumn;
    final chars = <int>[];
    while (value > 0) {
      value--;
      chars.add(65 + (value % 26));
      value ~/= 26;
    }
    return String.fromCharCodes(chars.reversed);
  }

  List<_DocumentBlueprint> _buildBlueprints({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
    required DateTime generatedAt,
  }) {
    final workName = _valueOrDash(
      purchaseFile.approvalDetails.workName,
      fallback: purchaseFile.title,
    );
    final description = _valueOrDash(
      purchaseFile.approvalDetails.workDescription,
      fallback: purchaseFile.description,
    );
    final organization = settings.organizationName;
    final itemsTable = _TableSection(
      title: 'Malzeme Listesi',
      headers: const ['No', 'Malzeme', 'Miktar', 'Birim'],
      rows: [
        for (var i = 0; i < purchaseFile.items.length; i++)
          [
            '${i + 1}',
            _valueOrDash(purchaseFile.items[i].name),
            _quantityText(purchaseFile.items[i].quantity),
            purchaseFile.items[i].unit,
          ],
      ],
    );
    final quotesTable = _TableSection(
      title: 'Teklif Karşılaştırması',
      headers: [
        'Malzeme',
        'Miktar',
        for (final vendor in purchaseFile.vendors)
          _valueOrDash(vendor.name, fallback: 'Firma ${vendor.slot}'),
      ],
      rows: [
        for (final item in purchaseFile.items)
          [
            _valueOrDash(item.name),
            '${_quantityText(item.quantity)} ${item.unit}',
            for (final vendor in purchaseFile.vendors)
              _currencyOrDash(
                quoteFor(
                  purchaseFile: purchaseFile,
                  itemId: item.id,
                  vendorId: vendor.id,
                )?.unitPrice,
              ),
          ],
      ],
    );
    final vendorTotalsTable = _TableSection(
      title: 'Firma Toplamları',
      headers: const ['Firma', 'Yetkili', 'Toplam'],
      rows: [
        for (final vendor in purchaseFile.vendors)
          [
            _valueOrDash(vendor.name, fallback: 'Firma ${vendor.slot}'),
            _valueOrDash(vendor.contactName),
            _currencyFormatter.format(vendorTotal(purchaseFile, vendor.id)),
          ],
      ],
    );
    final vendorContactsTable = _TableSection(
      title: 'Firma Bilgileri',
      headers: const ['Firma', 'Yetkili', 'Telefon', 'E-posta'],
      rows: [
        for (final vendor in purchaseFile.vendors)
          [
            _valueOrDash(vendor.name, fallback: 'Firma ${vendor.slot}'),
            _valueOrDash(vendor.contactName),
            _valueOrDash(vendor.contactPhone),
            _valueOrDash(vendor.contactEmail),
          ],
      ],
    );
    final committeeTable = _TableSection(
      title: 'Komisyon Üyeleri',
      headers: const ['Görev', 'Ad Soyad'],
      rows: [
        for (final member in settings.committeeMembers)
          [_valueOrDash(member.role), _valueOrDash(member.fullName)],
      ],
    );
    final inspectionTable = _TableSection(
      title: 'Muayene Heyeti',
      headers: const ['Görev', 'Ad Soyad'],
      rows: [
        for (final member in settings.inspectionMembers)
          [_valueOrDash(member.role), _valueOrDash(member.fullName)],
      ],
    );
    final commonInfo = _KeyValueSection(
      title: 'Genel Bilgiler',
      entries: [
        MapEntry('Kurum', _valueOrDash(organization)),
        MapEntry('Dosya başlığı', _valueOrDash(purchaseFile.title)),
        MapEntry('Belge numarası', _valueOrDash(purchaseFile.documentNumber)),
        MapEntry('Talep tarihi', _dateOrDash(purchaseFile.requestDate)),
        MapEntry('Teklif son tarihi', _dateOrDash(purchaseFile.offerDeadline)),
        MapEntry('Onay tarihi', _dateOrDash(purchaseFile.approvalDate)),
        MapEntry('Ekonomik kod', _valueOrDash(purchaseFile.economicCode)),
      ],
    );
    final approvalInfo = _KeyValueSection(
      title: 'Onay ve Bütçe',
      entries: [
        MapEntry('İşin adı', workName),
        MapEntry(
          'İşin niteliği',
          _valueOrDash(purchaseFile.approvalDetails.workNature),
        ),
        MapEntry('Açıklama', description),
        MapEntry(
          'Usul',
          _valueOrDash(purchaseFile.approvalDetails.procurementMethod),
        ),
        MapEntry(
          'Ödeme',
          _valueOrDash(purchaseFile.approvalDetails.paymentTerms),
        ),
        MapEntry(
          'İlan',
          _valueOrDash(purchaseFile.approvalDetails.announcementTerms),
        ),
        MapEntry(
          'Teminat',
          _valueOrDash(purchaseFile.approvalDetails.warrantyTerms),
        ),
        MapEntry(
          'Yaklaşık maliyet',
          _currencyFormatter.format(approximateCost(purchaseFile)),
        ),
      ],
    );
    final inspectionInfo = _KeyValueSection(
      title: 'Teslim ve Muayene',
      entries: [
        MapEntry(
          'Fatura tarihi',
          _dateOrDash(purchaseFile.inspectionDetails.invoiceDate),
        ),
        MapEntry(
          'Müzekkere tarihi',
          _dateOrDash(purchaseFile.inspectionDetails.dispatchDate),
        ),
        MapEntry(
          'Satan firma',
          _valueOrDash(purchaseFile.inspectionDetails.sellerCompanyName),
        ),
        MapEntry(
          'Teslim eden',
          _valueOrDash(purchaseFile.inspectionDetails.deliveredBy),
        ),
        MapEntry(
          'Teslim yeri',
          _valueOrDash(purchaseFile.inspectionDetails.warehouseLocation),
        ),
        MapEntry(
          'KDV hariç fatura',
          _currencyOrDash(
            purchaseFile.inspectionDetails.invoiceAmountExcludingVat,
          ),
        ),
        MapEntry(
          'KDV dahil fatura',
          _currencyOrDash(
            purchaseFile.inspectionDetails.invoiceAmountIncludingVat,
          ),
        ),
      ],
    );

    final subtitle =
        'Dijital belge çıktısı • ${_dateOrDash(generatedAt)} • $organization';

    return [
      _DocumentBlueprint(
        title: 'Mal Alım Onay Belgesi',
        slug: 'mal_alim_onay_belgesi',
        subtitle: subtitle,
        paragraphs: [
          '$workName işi için mal alımı onayı hazırlanmıştır.',
          'Belge ${purchaseFile.approvalDetails.procurementMethod} usulüne göre düzenlenmiş olup satın alma bilgileri aşağıda özetlenmiştir.',
        ],
        keyValueSections: [commonInfo, approvalInfo],
        tables: [itemsTable, vendorTotalsTable, committeeTable],
        footer:
            'Bu çıktı uygulama tarafından otomatik oluşturulmuştur. Nihai onaydan önce kurum bilgilerini ve maliyetleri kontrol edin.',
      ),
      _DocumentBlueprint(
        title: 'Yaklaşık Maliyet Cetveli',
        slug: 'yaklasik_maliyet_cetveli',
        subtitle: subtitle,
        paragraphs: [
          'Yaklaşık maliyet, teklif girilmiş firmaların toplam bedellerinin ortalaması alınarak hesaplanmıştır.',
        ],
        keyValueSections: [commonInfo],
        tables: [quotesTable, vendorTotalsTable],
        footer:
            'Yaklaşık maliyet: ${_currencyFormatter.format(approximateCost(purchaseFile))}',
      ),
      _DocumentBlueprint(
        title: 'Piyasa Fiyat Araştırması Tutanağı',
        slug: 'piyasa_fiyat_arastirmasi_tutanagi',
        subtitle: subtitle,
        paragraphs: [
          'Piyasa fiyat araştırması kapsamında firmalardan alınan birim fiyat teklifleri karşılaştırılmıştır.',
          _valueOrDash(purchaseFile.approvalDetails.marketResearchText),
        ],
        keyValueSections: [commonInfo],
        tables: [vendorContactsTable, quotesTable, committeeTable],
        footer:
            'Bu tutanakta boş bırakılan teklif alanları hesaplamaya dahil edilmemiştir.',
      ),
      _DocumentBlueprint(
        title: 'Teklif Mektubu',
        slug: 'teklif_mektubu',
        subtitle: subtitle,
        paragraphs: [
          '$organization tarafından aşağıdaki malzemeler için teklif talep edilmektedir.',
          'Lütfen tekliflerinizi ${_dateOrDash(purchaseFile.offerDeadline)} tarihine kadar iletiniz.',
        ],
        keyValueSections: [commonInfo, approvalInfo],
        tables: [itemsTable, vendorContactsTable],
        footer:
            'Teklif mektubu dijital ortamda oluşturulmuştur. İletişim ve termin bilgilerini kontrol edin.',
      ),
      _DocumentBlueprint(
        title: 'Fiyat Sorma Yazısı',
        slug: 'fiyat_sorma_yazisi',
        subtitle: subtitle,
        paragraphs: [
          '$workName kapsamında kullanılacak malzemeler için fiyat araştırması yazısıdır.',
          'Birim fiyatların KDV durumu belirtilerek paylaşılması beklenmektedir.',
        ],
        keyValueSections: [commonInfo],
        tables: [itemsTable, vendorContactsTable],
        footer:
            'Fiyat sorma yazısı, teklif toplamlarını otomatik hesaplayacak veri düzeniyle hazırlanmıştır.',
      ),
      _DocumentBlueprint(
        title: 'Muayene Raporu',
        slug: 'muayene_raporu',
        subtitle: subtitle,
        paragraphs: [
          'Teslim edilen malzemelerin muayene ve kabul sürecine ait özet bilgiler aşağıdadır.',
          _valueOrDash(purchaseFile.inspectionDetails.notes),
        ],
        keyValueSections: [commonInfo, inspectionInfo],
        tables: [itemsTable, inspectionTable],
        footer:
            'Muayene raporu oluşturuldu. Fatura ve teslim bilgileriyle üyelerin isimlerini son kez kontrol edin.',
      ),
    ];
  }
}

class _BestQuote {
  const _BestQuote({
    required this.vendor,
    required this.unitPrice,
    required this.total,
  });

  final Vendor vendor;
  final double unitPrice;
  final double total;
}

class _PdfFontBundle {
  _PdfFontBundle({required this.regular, required this.bold});

  final pw.Font regular;
  final pw.Font bold;

  static Future<_PdfFontBundle>? _future;

  static Future<_PdfFontBundle> load() {
    return _future ??= _loadFonts();
  }

  static Future<_PdfFontBundle> _loadFonts() async {
    final regularData = await rootBundle.load(
      'assets/fonts/NotoSans-Regular.ttf',
    );
    final boldData = await rootBundle.load('assets/fonts/NotoSans-Bold.ttf');

    return _PdfFontBundle(
      regular: pw.Font.ttf(regularData),
      bold: pw.Font.ttf(boldData),
    );
  }
}

class _DocumentBlueprint {
  const _DocumentBlueprint({
    required this.title,
    required this.slug,
    required this.subtitle,
    required this.paragraphs,
    required this.keyValueSections,
    required this.tables,
    required this.footer,
  });

  final String title;
  final String slug;
  final String subtitle;
  final List<String> paragraphs;
  final List<_KeyValueSection> keyValueSections;
  final List<_TableSection> tables;
  final String footer;
}

class _KeyValueSection {
  const _KeyValueSection({required this.title, required this.entries});

  final String title;
  final List<MapEntry<String, String>> entries;
}

class _TableSection {
  const _TableSection({
    required this.title,
    required this.headers,
    required this.rows,
  });

  final String title;
  final List<String> headers;
  final List<List<String>> rows;
}
