import 'package:satin_alma_evrak/features/documents/data/document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseDocumentGenerationService implements DocumentGenerationService {
  SupabaseDocumentGenerationService(this.functionName);

  final String functionName;

  SupabaseClient get _client => Supabase.instance.client;

  @override
  Future<List<GeneratedDocument>> generateDocuments({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) async {
    final response = await _client.functions.invoke(
      functionName,
      body: {
        'purchase_file': purchaseFile.toJson(),
        'organization_settings': settings.toJson(),
      },
    );

    final data = response.data;
    if (data is Map<String, dynamic> && data['documents'] is List<dynamic>) {
      return (data['documents'] as List<dynamic>)
          .map((row) => GeneratedDocument.fromJson(
                Map<String, dynamic>.from(row as Map),
              ))
          .toList();
    }

    return listDocuments(purchaseFile.id);
  }

  @override
  Future<List<GeneratedDocument>> listDocuments(String purchaseFileId) async {
    final response = await _client
        .from('document_exports')
        .select()
        .eq('purchase_file_id', purchaseFileId)
        .order('created_at', ascending: false);

    return (response as List<dynamic>)
        .map((row) => GeneratedDocument.fromJson(Map<String, dynamic>.from(row as Map)))
        .toList();
  }
}
