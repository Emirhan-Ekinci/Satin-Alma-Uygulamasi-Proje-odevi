import 'package:satin_alma_evrak/features/documents/data/document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/data/local_document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class DemoDocumentGenerationService implements DocumentGenerationService {
  DemoDocumentGenerationService._();

  static final DemoDocumentGenerationService instance =
      DemoDocumentGenerationService._();

  final Map<String, List<GeneratedDocument>> _cache = {};
  final LocalDocumentGenerationService _localGenerator =
      LocalDocumentGenerationService();

  @override
  Future<List<GeneratedDocument>> generateDocuments({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) async {
    final docs = await _localGenerator.generateDocuments(
      purchaseFile: purchaseFile,
      settings: settings,
    );
    _cache[purchaseFile.id] = docs;
    return docs;
  }

  @override
  Future<List<GeneratedDocument>> listDocuments(String purchaseFileId) async {
    return _cache[purchaseFileId] ?? const [];
  }
}
