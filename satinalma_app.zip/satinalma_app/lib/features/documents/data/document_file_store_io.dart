import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'document_file_store.dart';

class IoDocumentFileStore implements DocumentFileStore {
  @override
  Future<StoredDocumentFile> writeBytes({
    required String folderName,
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    final baseDir = await getApplicationDocumentsDirectory();
    final exportDir = Directory(
      p.join(baseDir.path, 'satin_alma_evrak', 'exports', folderName),
    );
    await exportDir.create(recursive: true);

    final file = File(p.join(exportDir.path, fileName));
    await file.writeAsBytes(bytes, flush: true);

    return StoredDocumentFile(
      reference: file.path,
      note: 'Dosya kaydedildi: ${file.path}',
    );
  }
}

DocumentFileStore createPlatformDocumentFileStore() => IoDocumentFileStore();
