import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satin_alma_evrak/core/firebase/firestore_serializers.dart';
import 'package:satin_alma_evrak/features/documents/data/document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/data/local_document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class FirebaseDocumentGenerationService implements DocumentGenerationService {
  FirebaseDocumentGenerationService({
    FirebaseFirestore? firestore,
    LocalDocumentGenerationService? localGenerator,
    required String userId,
  }) : _firestore = firestore ?? FirebaseFirestore.instance,
       _localGenerator = localGenerator ?? LocalDocumentGenerationService(),
       _userId = userId;

  final FirebaseFirestore _firestore;
  final LocalDocumentGenerationService _localGenerator;
  final String _userId;

  CollectionReference<Map<String, dynamic>> _documentsCollection(
    String purchaseFileId,
  ) => _firestore
      .collection('users')
      .doc(_userId)
      .collection('purchase_files')
      .doc(purchaseFileId)
      .collection('document_exports');

  @override
  Future<List<GeneratedDocument>> generateDocuments({
    required PurchaseFile purchaseFile,
    required OrganizationSettings settings,
  }) async {
    final documents = await _localGenerator.generateDocuments(
      purchaseFile: purchaseFile,
      settings: settings,
    );

    final batch = _firestore.batch();
    final collection = _documentsCollection(purchaseFile.id);
    for (final document in documents) {
      batch.set(
        collection.doc(document.id),
        FirestoreSerializers.generatedDocumentToFirestore(document),
      );
    }
    await batch.commit();

    return documents;
  }

  @override
  Future<List<GeneratedDocument>> listDocuments(String purchaseFileId) async {
    final snapshot = await _documentsCollection(
      purchaseFileId,
    ).orderBy('created_at', descending: true).get();

    return snapshot.docs
        .map(
          (doc) => GeneratedDocument.fromJson(
            FirestoreSerializers.generatedDocumentFromFirestore(doc.data()),
          ),
        )
        .toList();
  }
}
