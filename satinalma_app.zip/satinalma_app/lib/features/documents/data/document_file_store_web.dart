// ignore_for_file: deprecated_member_use, avoid_web_libraries_in_flutter

import 'dart:html' as html;
import 'dart:typed_data';

import 'document_file_store.dart';

class WebDocumentFileStore implements DocumentFileStore {
  @override
  Future<StoredDocumentFile> writeBytes({
    required String folderName,
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    final blob = html.Blob([bytes], mimeType);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..download = fileName
      ..style.display = 'none';

    html.document.body?.append(anchor);
    anchor.click();
    anchor.remove();

    return const StoredDocumentFile(
      reference: null,
      note: 'Tarayıcı indirme işlemi başlatıldı.',
    );
  }
}

DocumentFileStore createPlatformDocumentFileStore() => WebDocumentFileStore();
