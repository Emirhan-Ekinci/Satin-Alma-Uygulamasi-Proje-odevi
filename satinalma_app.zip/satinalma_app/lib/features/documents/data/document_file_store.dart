import 'dart:typed_data';

import 'document_file_store_io.dart'
    if (dart.library.html) 'document_file_store_web.dart';

abstract class DocumentFileStore {
  Future<StoredDocumentFile> writeBytes({
    required String folderName,
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  });
}

class StoredDocumentFile {
  const StoredDocumentFile({
    required this.reference,
    required this.note,
  });

  final String? reference;
  final String note;
}

DocumentFileStore createDocumentFileStore() => createPlatformDocumentFileStore();
