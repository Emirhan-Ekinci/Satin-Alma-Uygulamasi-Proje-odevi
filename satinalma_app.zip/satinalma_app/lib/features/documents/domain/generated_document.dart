class GeneratedDocument {
  const GeneratedDocument({
    required this.id,
    required this.purchaseFileId,
    required this.documentType,
    required this.format,
    required this.status,
    required this.fileName,
    required this.downloadUrl,
    required this.notes,
    required this.createdAt,
  });

  final String id;
  final String purchaseFileId;
  final String documentType;
  final String format;
  final String status;
  final String fileName;
  final String? downloadUrl;
  final String notes;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'purchase_file_id': purchaseFileId,
        'document_type': documentType,
        'format': format,
        'status': status,
        'file_name': fileName,
        'download_url': downloadUrl,
        'notes': notes,
        'created_at': createdAt.toIso8601String(),
      };

  factory GeneratedDocument.fromJson(Map<String, dynamic> json) {
    return GeneratedDocument(
      id: (json['id'] ?? '') as String,
      purchaseFileId: (json['purchase_file_id'] ?? '') as String,
      documentType: (json['document_type'] ?? '') as String,
      format: (json['format'] ?? '') as String,
      status: (json['status'] ?? '') as String,
      fileName: (json['file_name'] ?? '') as String,
      downloadUrl: json['download_url'] as String?,
      notes: (json['notes'] ?? '') as String,
      createdAt: DateTime.parse(
        (json['created_at'] ?? DateTime.now().toIso8601String()) as String,
      ),
    );
  }
}
