import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/documents/data/document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/data/settings_repository.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

export 'package:satin_alma_evrak/features/auth/application/auth_providers.dart';

final isDemoModeProvider = Provider<bool>(
  (ref) => !ref.watch(appConfigProvider).useFirebase,
);

final organizationSettingsProvider = FutureProvider<OrganizationSettings>(
  (ref) => ref.watch(settingsRepositoryProvider).getSettings(),
);

final purchaseFilesProvider = FutureProvider<List<PurchaseFile>>(
  (ref) => ref.watch(purchaseFileRepositoryProvider).fetchAll(),
);

final selectedPurchaseFileIdProvider = StateProvider<String?>((ref) => null);
final shellIndexProvider = StateProvider<int>((ref) => 0);

final documentsProvider =
    FutureProvider.family<List<GeneratedDocument>, String>((ref, purchaseFileId) {
  return ref
      .watch(documentGenerationServiceProvider)
      .listDocuments(purchaseFileId);
});
