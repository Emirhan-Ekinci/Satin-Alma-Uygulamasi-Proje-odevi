import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satin_alma_evrak/core/firebase/firestore_serializers.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class FirebasePurchaseFileRepository implements PurchaseFileRepository {
  FirebasePurchaseFileRepository({FirebaseFirestore? firestore, required String userId})
    : _firestore = firestore ?? FirebaseFirestore.instance,
      _userId = userId;

  final FirebaseFirestore _firestore;
  final String _userId;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection('users').doc(_userId).collection('purchase_files');

  @override
  Future<PurchaseFile> createFromSettings(OrganizationSettings settings) async {
    final file = PurchaseFile.createFromSettings(settings);
    await save(file);
    return file;
  }

  @override
  Future<void> delete(String id) {
    return _collection.doc(id).delete();
  }

  @override
  Future<List<PurchaseFile>> fetchAll() async {
    final snapshot = await _collection
        .orderBy('updated_at', descending: true)
        .get();

    return snapshot.docs
        .map(
          (doc) => PurchaseFile.fromJson(
            FirestoreSerializers.purchaseFileFromFirestore(doc.data()),
          ),
        )
        .toList();
  }

  @override
  Future<void> save(PurchaseFile file) {
    final updated = file.copyWith(
      userId: _userId,
      updatedAt: DateTime.now(),
    );
    return _collection
        .doc(updated.id)
        .set(FirestoreSerializers.purchaseFileToFirestore(updated));
  }
}
