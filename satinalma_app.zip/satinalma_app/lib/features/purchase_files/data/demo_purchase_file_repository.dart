import 'package:satin_alma_evrak/features/purchase_files/data/purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

class DemoPurchaseFileRepository implements PurchaseFileRepository {
  DemoPurchaseFileRepository._();

  static final DemoPurchaseFileRepository instance =
      DemoPurchaseFileRepository._();

  final List<PurchaseFile> _files = [];

  @override
  Future<PurchaseFile> createFromSettings(OrganizationSettings settings) async {
    final file = PurchaseFile.createFromSettings(settings);
    _files.insert(0, file);
    return file;
  }

  @override
  Future<void> delete(String id) async {
    _files.removeWhere((file) => file.id == id);
  }

  @override
  Future<List<PurchaseFile>> fetchAll() async {
    return _files
        .map(
          (file) => file.copyWith(
            items: [...file.items],
            vendors: [...file.vendors],
            quotes: [...file.quotes],
          ),
        )
        .toList();
  }

  @override
  Future<void> save(PurchaseFile file) async {
    final index = _files.indexWhere((element) => element.id == file.id);
    if (index == -1) {
      _files.insert(0, file);
      return;
    }
    _files[index] = file.copyWith(updatedAt: DateTime.now());
  }
}
