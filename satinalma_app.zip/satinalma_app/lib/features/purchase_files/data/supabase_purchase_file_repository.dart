import 'package:satin_alma_evrak/features/purchase_files/data/purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabasePurchaseFileRepository implements PurchaseFileRepository {
  SupabaseClient get _client => Supabase.instance.client;

  @override
  Future<PurchaseFile> createFromSettings(OrganizationSettings settings) async {
    final file = PurchaseFile.createFromSettings(settings);
    await save(file);
    return file;
  }

  @override
  Future<void> delete(String id) async {
    await _client.from('purchase_files').delete().eq('id', id);
  }

  @override
  Future<List<PurchaseFile>> fetchAll() async {
    final response = await _client.from('purchase_files').select('''
          *,
          purchase_items (*),
          vendors (*),
          vendor_quotes (*)
        ''').order('updated_at', ascending: false);

    return (response as List<dynamic>).map((row) {
      final json = Map<String, dynamic>.from(row as Map);
      return PurchaseFile.fromJson({
        ...json,
        'items': json['purchase_items'] ?? <dynamic>[],
        'vendors': json['vendors'] ?? <dynamic>[],
        'quotes': json['vendor_quotes'] ?? <dynamic>[],
      });
    }).toList();
  }

  @override
  Future<void> save(PurchaseFile file) async {
    final updated = file.copyWith(updatedAt: DateTime.now());
    await _client.from('purchase_files').upsert({
      'id': updated.id,
      'title': updated.title,
      'description': updated.description,
      'document_number': updated.documentNumber,
      'request_date': updated.requestDate?.toIso8601String(),
      'offer_deadline': updated.offerDeadline?.toIso8601String(),
      'approval_date': updated.approvalDate?.toIso8601String(),
      'economic_code': updated.economicCode,
      'notes': updated.notes,
      'approval_details': updated.approvalDetails.toJson(),
      'inspection_details': updated.inspectionDetails.toJson(),
      'organization_snapshot': updated.organizationSnapshot.toJson(),
      'created_at': updated.createdAt.toIso8601String(),
      'updated_at': updated.updatedAt.toIso8601String(),
    });

    await _client.from('purchase_items').delete().eq('purchase_file_id', file.id);
    await _client.from('vendors').delete().eq('purchase_file_id', file.id);
    await _client.from('vendor_quotes').delete().eq('purchase_file_id', file.id);

    if (updated.items.isNotEmpty) {
      await _client.from('purchase_items').insert(
            updated.items.asMap().entries.map((entry) {
              final item = entry.value;
              return {
                'id': item.id,
                'purchase_file_id': updated.id,
                'name': item.name,
                'quantity': item.quantity,
                'unit': item.unit,
                'sort_order': entry.key,
              };
            }).toList(),
          );
    }

    if (updated.vendors.isNotEmpty) {
      await _client.from('vendors').insert(
            updated.vendors.map((vendor) {
              return {
                'id': vendor.id,
                'purchase_file_id': updated.id,
                'slot': vendor.slot,
                'name': vendor.name,
                'contact_name': vendor.contactName,
                'contact_email': vendor.contactEmail,
                'contact_phone': vendor.contactPhone,
                'address': vendor.address,
              };
            }).toList(),
          );
    }

    if (updated.quotes.isNotEmpty) {
      await _client.from('vendor_quotes').insert(
            updated.quotes.map((quote) {
              return {
                'id': quote.id,
                'purchase_file_id': updated.id,
                'purchase_item_id': quote.purchaseItemId,
                'vendor_id': quote.vendorId,
                'unit_price': quote.unitPrice,
              };
            }).toList(),
          );
    }
  }
}
