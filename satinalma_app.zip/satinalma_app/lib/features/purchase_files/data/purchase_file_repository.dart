import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/config/app_config.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/demo_purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/firebase_purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/auth/application/auth_providers.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

abstract class PurchaseFileRepository {
  Future<List<PurchaseFile>> fetchAll();

  Future<PurchaseFile> createFromSettings(OrganizationSettings settings);

  Future<void> save(PurchaseFile file);

  Future<void> delete(String id);
}

final purchaseFileRepositoryProvider = Provider<PurchaseFileRepository>((ref) {
  final config = ref.watch(appConfigProvider);
  if (config.useFirebase) {
    final userId = ref.watch(currentUserIdProvider);
    return FirebasePurchaseFileRepository(
      userId: userId,
    );
  }
  return DemoPurchaseFileRepository.instance;
});
