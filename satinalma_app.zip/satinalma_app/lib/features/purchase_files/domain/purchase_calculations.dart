import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';

const double defaultVatRate = 0.20;

VendorQuote? quoteFor({
  required PurchaseFile purchaseFile,
  required String itemId,
  required String vendorId,
}) {
  for (final quote in purchaseFile.quotes) {
    if (quote.purchaseItemId == itemId && quote.vendorId == vendorId) {
      return quote;
    }
  }
  return null;
}

double vendorLineTotal({
  required PurchaseItem item,
  required VendorQuote? quote,
}) {
  if (quote?.unitPrice == null) {
    return 0;
  }
  return item.quantity * quote!.unitPrice!;
}

bool vendorHasAnyQuote(PurchaseFile purchaseFile, String vendorId) {
  return purchaseFile.quotes.any(
    (quote) => quote.vendorId == vendorId && quote.unitPrice != null,
  );
}

double vendorTotal(PurchaseFile purchaseFile, String vendorId) {
  double total = 0;
  for (final item in purchaseFile.items) {
    total += vendorLineTotal(
      item: item,
      quote: quoteFor(
        purchaseFile: purchaseFile,
        itemId: item.id,
        vendorId: vendorId,
      ),
    );
  }
  return total;
}

double approximateCost(PurchaseFile purchaseFile) {
  final totals = purchaseFile.vendors
      .where((vendor) => vendorHasAnyQuote(purchaseFile, vendor.id))
      .map((vendor) => vendorTotal(purchaseFile, vendor.id))
      .toList();

  if (totals.isEmpty) {
    return 0;
  }

  return totals.reduce((sum, item) => sum + item) / totals.length;
}

double lowestVendorTotal(PurchaseFile purchaseFile) {
  final totals = purchaseFile.vendors
      .where((vendor) => vendorHasAnyQuote(purchaseFile, vendor.id))
      .map((vendor) => vendorTotal(purchaseFile, vendor.id))
      .toList();

  if (totals.isEmpty) {
    return 0;
  }

  totals.sort();
  return totals.first;
}

Vendor? lowestQuotedVendor(PurchaseFile purchaseFile) {
  Vendor? selectedVendor;
  double? selectedTotal;

  for (final vendor in purchaseFile.vendors) {
    if (!vendorHasAnyQuote(purchaseFile, vendor.id)) {
      continue;
    }

    final total = vendorTotal(purchaseFile, vendor.id);
    if (selectedTotal == null || total < selectedTotal) {
      selectedVendor = vendor;
      selectedTotal = total;
    }
  }

  return selectedVendor;
}

double? preferredInvoiceAmountExcludingVat(PurchaseFile purchaseFile) {
  final explicit = purchaseFile.inspectionDetails.invoiceAmountExcludingVat;
  if (explicit != null) {
    return explicit;
  }

  final vendor = lowestQuotedVendor(purchaseFile);
  if (vendor == null) {
    return null;
  }

  return vendorTotal(purchaseFile, vendor.id);
}

double? preferredInvoiceAmountIncludingVat(
  PurchaseFile purchaseFile, {
  double vatRate = defaultVatRate,
}) {
  final explicit = purchaseFile.inspectionDetails.invoiceAmountIncludingVat;
  if (explicit != null) {
    return explicit;
  }

  final excludingVat = preferredInvoiceAmountExcludingVat(purchaseFile);
  if (excludingVat == null) {
    return null;
  }

  return excludingVat * (1 + vatRate);
}

String preferredSellerCompanyName(PurchaseFile purchaseFile) {
  final explicit = purchaseFile.inspectionDetails.sellerCompanyName.trim();
  if (explicit.isNotEmpty) {
    return explicit;
  }

  return lowestQuotedVendor(purchaseFile)?.name.trim() ?? '';
}

InspectionDetails resolvedInspectionDetails(
  PurchaseFile purchaseFile, {
  double vatRate = defaultVatRate,
}) {
  return purchaseFile.inspectionDetails.copyWith(
    invoiceAmountExcludingVat: preferredInvoiceAmountExcludingVat(purchaseFile),
    invoiceAmountIncludingVat: preferredInvoiceAmountIncludingVat(
      purchaseFile,
      vatRate: vatRate,
    ),
    sellerCompanyName: preferredSellerCompanyName(purchaseFile),
  );
}

int totalQuotedVendorCount(PurchaseFile purchaseFile) {
  return purchaseFile.vendors
      .where((vendor) => vendorHasAnyQuote(purchaseFile, vendor.id))
      .length;
}
