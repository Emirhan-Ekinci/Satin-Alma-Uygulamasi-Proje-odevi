import 'dart:math';

import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';

String newId([String prefix = 'id']) =>
    '$prefix-${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(1 << 30)}';

const purchaseUnitOptions = ['ADET', 'MAKARA', 'TOP', 'TAKIM'];

String vendorIdForPurchaseFile(String purchaseFileId, int slot) =>
    '$purchaseFileId-vendor-$slot';

class PurchaseItem {
  const PurchaseItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.unit,
  });

  factory PurchaseItem.empty() {
    return PurchaseItem(
      id: newId('item'),
      name: '',
      quantity: 1,
      unit: 'ADET',
    );
  }

  final String id;
  final String name;
  final double quantity;
  final String unit;

  PurchaseItem copyWith({
    String? id,
    String? name,
    double? quantity,
    String? unit,
  }) {
    return PurchaseItem(
      id: id ?? this.id,
      name: name ?? this.name,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'quantity': quantity,
        'unit': unit,
      };

  factory PurchaseItem.fromJson(Map<String, dynamic> json) {
    final rawUnit = (json['unit'] ?? '').toString().trim().toUpperCase();
    return PurchaseItem(
      id: (json['id'] ?? newId('item')) as String,
      name: (json['name'] ?? '') as String,
      quantity: (json['quantity'] as num?)?.toDouble() ?? 0,
      unit: purchaseUnitOptions.contains(rawUnit) ? rawUnit : 'ADET',
    );
  }
}

class Vendor {
  const Vendor({
    required this.id,
    required this.slot,
    required this.name,
    required this.contactName,
    required this.contactEmail,
    required this.contactPhone,
    required this.address,
  });

  factory Vendor.empty({required int slot}) {
    return Vendor(
      id: newId('vendor'),
      slot: slot,
      name: 'Firma $slot',
      contactName: '',
      contactEmail: '',
      contactPhone: '',
      address: '',
    );
  }

  final String id;
  final int slot;
  final String name;
  final String contactName;
  final String contactEmail;
  final String contactPhone;
  final String address;

  Vendor copyWith({
    String? id,
    int? slot,
    String? name,
    String? contactName,
    String? contactEmail,
    String? contactPhone,
    String? address,
  }) {
    return Vendor(
      id: id ?? this.id,
      slot: slot ?? this.slot,
      name: name ?? this.name,
      contactName: contactName ?? this.contactName,
      contactEmail: contactEmail ?? this.contactEmail,
      contactPhone: contactPhone ?? this.contactPhone,
      address: address ?? this.address,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'slot': slot,
        'name': name,
        'contact_name': contactName,
        'contact_email': contactEmail,
        'contact_phone': contactPhone,
        'address': address,
      };

  factory Vendor.fromJson(Map<String, dynamic> json) {
    return Vendor(
      id: (json['id'] ?? newId('vendor')) as String,
      slot: (json['slot'] as num?)?.toInt() ?? 1,
      name: (json['name'] ?? '') as String,
      contactName: (json['contact_name'] ?? '') as String,
      contactEmail: (json['contact_email'] ?? '') as String,
      contactPhone: (json['contact_phone'] ?? '') as String,
      address: (json['address'] ?? '') as String,
    );
  }
}

class VendorQuote {
  const VendorQuote({
    required this.id,
    required this.purchaseItemId,
    required this.vendorId,
    required this.unitPrice,
  });

  factory VendorQuote.empty({
    required String purchaseItemId,
    required String vendorId,
  }) {
    return VendorQuote(
      id: newId('quote'),
      purchaseItemId: purchaseItemId,
      vendorId: vendorId,
      unitPrice: null,
    );
  }

  final String id;
  final String purchaseItemId;
  final String vendorId;
  final double? unitPrice;

  VendorQuote copyWith({
    String? id,
    String? purchaseItemId,
    String? vendorId,
    double? unitPrice,
    bool clearPrice = false,
  }) {
    return VendorQuote(
      id: id ?? this.id,
      purchaseItemId: purchaseItemId ?? this.purchaseItemId,
      vendorId: vendorId ?? this.vendorId,
      unitPrice: clearPrice ? null : unitPrice ?? this.unitPrice,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'purchase_item_id': purchaseItemId,
        'vendor_id': vendorId,
        'unit_price': unitPrice,
      };

  factory VendorQuote.fromJson(Map<String, dynamic> json) {
    return VendorQuote(
      id: (json['id'] ?? newId('quote')) as String,
      purchaseItemId: (json['purchase_item_id'] ?? '') as String,
      vendorId: (json['vendor_id'] ?? '') as String,
      unitPrice: (json['unit_price'] as num?)?.toDouble(),
    );
  }
}

class ApprovalDetails {
  const ApprovalDetails({
    required this.workName,
    required this.workNature,
    required this.workDescription,
    required this.budgetCode,
    required this.fundSource,
    required this.paymentTerms,
    required this.announcementTerms,
    required this.warrantyTerms,
    required this.procurementMethod,
    required this.marketResearchText,
    required this.additionalNotes,
  });

  factory ApprovalDetails.empty() {
    return const ApprovalDetails(
      workName: '',
      workNature: '',
      workDescription: '',
      budgetCode: '',
      fundSource: '',
      paymentTerms: 'Ödenmeyecek',
      announcementTerms: 'İlan verilmeyecek',
      warrantyTerms: 'Yok',
      procurementMethod: '4734/22-d',
      marketResearchText: '',
      additionalNotes: '',
    );
  }

  final String workName;
  final String workNature;
  final String workDescription;
  final String budgetCode;
  final String fundSource;
  final String paymentTerms;
  final String announcementTerms;
  final String warrantyTerms;
  final String procurementMethod;
  final String marketResearchText;
  final String additionalNotes;

  ApprovalDetails copyWith({
    String? workName,
    String? workNature,
    String? workDescription,
    String? budgetCode,
    String? fundSource,
    String? paymentTerms,
    String? announcementTerms,
    String? warrantyTerms,
    String? procurementMethod,
    String? marketResearchText,
    String? additionalNotes,
  }) {
    return ApprovalDetails(
      workName: workName ?? this.workName,
      workNature: workNature ?? this.workNature,
      workDescription: workDescription ?? this.workDescription,
      budgetCode: budgetCode ?? this.budgetCode,
      fundSource: fundSource ?? this.fundSource,
      paymentTerms: paymentTerms ?? this.paymentTerms,
      announcementTerms: announcementTerms ?? this.announcementTerms,
      warrantyTerms: warrantyTerms ?? this.warrantyTerms,
      procurementMethod: procurementMethod ?? this.procurementMethod,
      marketResearchText: marketResearchText ?? this.marketResearchText,
      additionalNotes: additionalNotes ?? this.additionalNotes,
    );
  }

  Map<String, dynamic> toJson() => {
        'work_name': workName,
        'work_nature': workNature,
        'work_description': workDescription,
        'budget_code': budgetCode,
        'fund_source': fundSource,
        'payment_terms': paymentTerms,
        'announcement_terms': announcementTerms,
        'warranty_terms': warrantyTerms,
        'procurement_method': procurementMethod,
        'market_research_text': marketResearchText,
        'additional_notes': additionalNotes,
      };

  factory ApprovalDetails.fromJson(Map<String, dynamic> json) {
    return ApprovalDetails(
      workName: (json['work_name'] ?? '') as String,
      workNature: (json['work_nature'] ?? '') as String,
      workDescription: (json['work_description'] ?? '') as String,
      budgetCode: (json['budget_code'] ?? '') as String,
      fundSource: (json['fund_source'] ?? '') as String,
      paymentTerms: (json['payment_terms'] ?? '') as String,
      announcementTerms: (json['announcement_terms'] ?? '') as String,
      warrantyTerms: (json['warranty_terms'] ?? '') as String,
      procurementMethod: (json['procurement_method'] ?? '') as String,
      marketResearchText: (json['market_research_text'] ?? '') as String,
      additionalNotes: (json['additional_notes'] ?? '') as String,
    );
  }
}

class InspectionDetails {
  const InspectionDetails({
    required this.invoiceDate,
    required this.invoiceAmountExcludingVat,
    required this.invoiceAmountIncludingVat,
    required this.stampTaxRate,
    required this.sellerCompanyName,
    required this.dispatchDate,
    required this.paymentOrderNumber,
    required this.deliveredBy,
    required this.warehouseLocation,
    required this.notes,
  });

  factory InspectionDetails.empty() {
    return const InspectionDetails(
      invoiceDate: null,
      invoiceAmountExcludingVat: null,
      invoiceAmountIncludingVat: null,
      stampTaxRate: 0.00825,
      sellerCompanyName: '',
      dispatchDate: null,
      paymentOrderNumber: '',
      deliveredBy: '',
      warehouseLocation: 'Okul Ambarı',
      notes: '',
    );
  }

  final DateTime? invoiceDate;
  final double? invoiceAmountExcludingVat;
  final double? invoiceAmountIncludingVat;
  final double stampTaxRate;
  final String sellerCompanyName;
  final DateTime? dispatchDate;
  final String paymentOrderNumber;
  final String deliveredBy;
  final String warehouseLocation;
  final String notes;

  InspectionDetails copyWith({
    DateTime? invoiceDate,
    double? invoiceAmountExcludingVat,
    double? invoiceAmountIncludingVat,
    double? stampTaxRate,
    String? sellerCompanyName,
    DateTime? dispatchDate,
    String? paymentOrderNumber,
    String? deliveredBy,
    String? warehouseLocation,
    String? notes,
    bool clearInvoiceDate = false,
    bool clearDispatchDate = false,
  }) {
    return InspectionDetails(
      invoiceDate: clearInvoiceDate ? null : invoiceDate ?? this.invoiceDate,
      invoiceAmountExcludingVat:
          invoiceAmountExcludingVat ?? this.invoiceAmountExcludingVat,
      invoiceAmountIncludingVat:
          invoiceAmountIncludingVat ?? this.invoiceAmountIncludingVat,
      stampTaxRate: stampTaxRate ?? this.stampTaxRate,
      sellerCompanyName: sellerCompanyName ?? this.sellerCompanyName,
      dispatchDate:
          clearDispatchDate ? null : dispatchDate ?? this.dispatchDate,
      paymentOrderNumber: paymentOrderNumber ?? this.paymentOrderNumber,
      deliveredBy: deliveredBy ?? this.deliveredBy,
      warehouseLocation: warehouseLocation ?? this.warehouseLocation,
      notes: notes ?? this.notes,
    );
  }

  Map<String, dynamic> toJson() => {
        'invoice_date': invoiceDate?.toIso8601String(),
        'invoice_amount_excluding_vat': invoiceAmountExcludingVat,
        'invoice_amount_including_vat': invoiceAmountIncludingVat,
        'stamp_tax_rate': stampTaxRate,
        'seller_company_name': sellerCompanyName,
        'dispatch_date': dispatchDate?.toIso8601String(),
        'payment_order_number': paymentOrderNumber,
        'delivered_by': deliveredBy,
        'warehouse_location': warehouseLocation,
        'notes': notes,
      };

  factory InspectionDetails.fromJson(Map<String, dynamic> json) {
    return InspectionDetails(
      invoiceDate: json['invoice_date'] == null
          ? null
          : DateTime.parse(json['invoice_date'] as String),
      invoiceAmountExcludingVat:
          (json['invoice_amount_excluding_vat'] as num?)?.toDouble(),
      invoiceAmountIncludingVat:
          (json['invoice_amount_including_vat'] as num?)?.toDouble(),
      stampTaxRate: (json['stamp_tax_rate'] as num?)?.toDouble() ?? 0.00825,
      sellerCompanyName: (json['seller_company_name'] ?? '') as String,
      dispatchDate: json['dispatch_date'] == null
          ? null
          : DateTime.parse(json['dispatch_date'] as String),
      paymentOrderNumber: (json['payment_order_number'] ?? '') as String,
      deliveredBy: (json['delivered_by'] ?? '') as String,
      warehouseLocation: (json['warehouse_location'] ?? '') as String,
      notes: (json['notes'] ?? '') as String,
    );
  }
}

class PurchaseFile {
  const PurchaseFile({
    required this.id,
    required this.title,
    required this.description,
    required this.documentNumber,
    required this.requestDate,
    required this.offerDeadline,
    required this.approvalDate,
    required this.economicCode,
    required this.notes,
    required this.items,
    required this.vendors,
    required this.quotes,
    required this.approvalDetails,
    required this.inspectionDetails,
    required this.organizationSnapshot,
    required this.userId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory PurchaseFile.createFromSettings(OrganizationSettings settings) {
    final now = DateTime.now();
    final purchaseId = newId('purchase');
    return PurchaseFile(
      id: purchaseId,
      title: 'Yeni Satın Alma Dosyası',
      description: '',
      documentNumber: '',
      requestDate: now,
      offerDeadline: now.add(const Duration(days: 2)),
      approvalDate: now,
      economicCode: '',
      notes: '',
      items: const [],
      vendors: List.generate(
        4,
        (index) => Vendor.empty(slot: index + 1).copyWith(
          id: vendorIdForPurchaseFile(purchaseId, index + 1),
        ),
      ),
      quotes: const [],
      approvalDetails: ApprovalDetails.empty().copyWith(
        marketResearchText:
            'Piyasa fiyat araştırması için görevlendirilen personel bilgisi burada gösterilecektir.',
      ),
      inspectionDetails: InspectionDetails.empty(),
      organizationSnapshot: settings,
      userId: '', // Will be set by repository
      createdAt: now,
      updatedAt: now,
    );
  }

  final String id;
  final String title;
  final String description;
  final String documentNumber;
  final DateTime? requestDate;
  final DateTime? offerDeadline;
  final DateTime? approvalDate;
  final String economicCode;
  final String notes;
  final List<PurchaseItem> items;
  final List<Vendor> vendors;
  final List<VendorQuote> quotes;
  final ApprovalDetails approvalDetails;
  final InspectionDetails inspectionDetails;
  final OrganizationSettings organizationSnapshot;
  final String userId;
  final DateTime createdAt;
  final DateTime updatedAt;

  PurchaseFile copyWith({
    String? id,
    String? title,
    String? description,
    String? documentNumber,
    DateTime? requestDate,
    DateTime? offerDeadline,
    DateTime? approvalDate,
    String? economicCode,
    String? notes,
    List<PurchaseItem>? items,
    List<Vendor>? vendors,
    List<VendorQuote>? quotes,
    ApprovalDetails? approvalDetails,
    InspectionDetails? inspectionDetails,
    OrganizationSettings? organizationSnapshot,
    String? userId,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool clearRequestDate = false,
    bool clearOfferDeadline = false,
    bool clearApprovalDate = false,
  }) {
    return PurchaseFile(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      documentNumber: documentNumber ?? this.documentNumber,
      requestDate: clearRequestDate ? null : requestDate ?? this.requestDate,
      offerDeadline:
          clearOfferDeadline ? null : offerDeadline ?? this.offerDeadline,
      approvalDate:
          clearApprovalDate ? null : approvalDate ?? this.approvalDate,
      economicCode: economicCode ?? this.economicCode,
      notes: notes ?? this.notes,
      items: items ?? this.items,
      vendors: vendors ?? this.vendors,
      quotes: quotes ?? this.quotes,
      approvalDetails: approvalDetails ?? this.approvalDetails,
      inspectionDetails: inspectionDetails ?? this.inspectionDetails,
      organizationSnapshot: organizationSnapshot ?? this.organizationSnapshot,
      userId: userId ?? this.userId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'document_number': documentNumber,
        'request_date': requestDate?.toIso8601String(),
        'offer_deadline': offerDeadline?.toIso8601String(),
        'approval_date': approvalDate?.toIso8601String(),
        'economic_code': economicCode,
        'notes': notes,
        'approval_details': approvalDetails.toJson(),
        'inspection_details': inspectionDetails.toJson(),
        'organization_snapshot': organizationSnapshot.toJson(),
        'user_id': userId,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'items': items.map((item) => item.toJson()).toList(),
        'vendors': vendors.map((vendor) => vendor.toJson()).toList(),
        'quotes': quotes.map((quote) => quote.toJson()).toList(),
      };

  factory PurchaseFile.fromJson(Map<String, dynamic> json) {
    return PurchaseFile(
      id: (json['id'] ?? newId('purchase')) as String,
      title: (json['title'] ?? '') as String,
      description: (json['description'] ?? '') as String,
      documentNumber: (json['document_number'] ?? '') as String,
      requestDate: json['request_date'] == null
          ? null
          : DateTime.parse(json['request_date'] as String),
      offerDeadline: json['offer_deadline'] == null
          ? null
          : DateTime.parse(json['offer_deadline'] as String),
      approvalDate: json['approval_date'] == null
          ? null
          : DateTime.parse(json['approval_date'] as String),
      economicCode: (json['economic_code'] ?? '') as String,
      notes: (json['notes'] ?? '') as String,
      items: (json['items'] as List<dynamic>? ?? <dynamic>[])
          .map((item) => PurchaseItem.fromJson(
                Map<String, dynamic>.from(item as Map),
              ))
          .toList(),
      vendors: (json['vendors'] as List<dynamic>? ?? <dynamic>[])
          .map((vendor) => Vendor.fromJson(
                Map<String, dynamic>.from(vendor as Map),
              ))
          .toList(),
      quotes: (json['quotes'] as List<dynamic>? ?? <dynamic>[])
          .map((quote) => VendorQuote.fromJson(
                Map<String, dynamic>.from(quote as Map),
              ))
          .toList(),
      approvalDetails: ApprovalDetails.fromJson(
        Map<String, dynamic>.from(
          (json['approval_details'] ?? <String, dynamic>{}) as Map,
        ),
      ),
      inspectionDetails: InspectionDetails.fromJson(
        Map<String, dynamic>.from(
          (json['inspection_details'] ?? <String, dynamic>{}) as Map,
        ),
      ),
      organizationSnapshot: OrganizationSettings.fromJson(
        Map<String, dynamic>.from(
          (json['organization_snapshot'] ?? <String, dynamic>{}) as Map,
        ),
      ),
      userId: (json['user_id'] ?? '') as String,
      createdAt: DateTime.parse(
        (json['created_at'] ?? DateTime.now().toIso8601String()) as String,
      ),
      updatedAt: DateTime.parse(
        (json['updated_at'] ?? DateTime.now().toIso8601String()) as String,
      ),
    );
  }
}
