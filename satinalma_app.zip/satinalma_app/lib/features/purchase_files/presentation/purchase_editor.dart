﻿import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/utils/formatters.dart';
import 'package:satin_alma_evrak/features/documents/data/document_generation_service.dart';
import 'package:satin_alma_evrak/features/documents/presentation/documents_tab.dart';
import 'package:satin_alma_evrak/features/purchase_files/application/purchase_providers.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_calculations.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';
import 'package:satin_alma_evrak/shared/widgets/section_card.dart';

class PurchaseEditor extends ConsumerStatefulWidget {
  const PurchaseEditor({
    super.key,
    required this.initialValue,
    required this.settings,
  });

  final PurchaseFile initialValue;
  final OrganizationSettings settings;

  @override
  ConsumerState<PurchaseEditor> createState() => _PurchaseEditorState();
}

class _PurchaseEditorState extends ConsumerState<PurchaseEditor> {
  late PurchaseFile _draft;
  final Map<String, TextEditingController> _quoteControllers = {};
  final ScrollController _generalScrollController = ScrollController();
  final ScrollController _itemsScrollController = ScrollController();
  final ScrollController _vendorsScrollController = ScrollController();
  final ScrollController _quotesScrollController = ScrollController();
  final ScrollController _approvalScrollController = ScrollController();
  final ScrollController _inspectionScrollController = ScrollController();
  bool _saving = false;
  bool _generating = false;
  static const double _mobileBreakpoint = 900;

  @override
  void initState() {
    super.initState();
    _draft = widget.initialValue;
    _normalizeVendorIdsIfNeeded();
    _syncQuoteControllers();
  }

  @override
  void didUpdateWidget(covariant PurchaseEditor oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialValue.id != widget.initialValue.id) {
      _draft = widget.initialValue;
      _normalizeVendorIdsIfNeeded();
      _disposeQuoteControllers();
      _syncQuoteControllers();
    }
  }

  @override
  void dispose() {
    _disposeQuoteControllers();
    _generalScrollController.dispose();
    _itemsScrollController.dispose();
    _vendorsScrollController.dispose();
    _quotesScrollController.dispose();
    _approvalScrollController.dispose();
    _inspectionScrollController.dispose();
    super.dispose();
  }

  String _quoteCellKey(String itemId, String vendorId) => '$itemId::$vendorId';

  void _normalizeVendorIdsIfNeeded() {
    final currentIds = _draft.vendors.map((vendor) => vendor.id).toList();
    final expectedIds = _draft.vendors
        .map((vendor) => vendorIdForPurchaseFile(_draft.id, vendor.slot))
        .toList();
    final hasDuplicateIds = currentIds.toSet().length != currentIds.length;
    final hasUnexpectedIds = currentIds.asMap().entries.any(
      (entry) => entry.value != expectedIds[entry.key],
    );

    if (!hasDuplicateIds && !hasUnexpectedIds) {
      return;
    }

    final quotesCanBeMapped = !hasDuplicateIds;
    final idMap = <String, String>{
      for (final vendor in _draft.vendors)
        vendor.id: vendorIdForPurchaseFile(_draft.id, vendor.slot),
    };

    _draft = _draft.copyWith(
      vendors: _draft.vendors
          .map(
            (vendor) => vendor.copyWith(
              id: vendorIdForPurchaseFile(_draft.id, vendor.slot),
            ),
          )
          .toList(),
      quotes: quotesCanBeMapped
          ? _draft.quotes
              .map(
                (quote) => quote.copyWith(
                  vendorId: idMap[quote.vendorId] ?? quote.vendorId,
                ),
              )
              .toList()
          : const <VendorQuote>[],
    );
  }

  void _disposeQuoteControllers() {
    for (final controller in _quoteControllers.values) {
      controller.dispose();
    }
    _quoteControllers.clear();
  }

  String _quoteText(double? value) {
    if (value == null) {
      return '';
    }
    if (value == value.roundToDouble()) {
      return value.toStringAsFixed(0);
    }
    return value.toString();
  }

  PurchaseFile get _resolvedDraft => _draft.copyWith(
        inspectionDetails: resolvedInspectionDetails(_draft),
      );

  void _syncQuoteControllers() {
    final validKeys = <String>{};

    for (final item in _draft.items) {
      for (final vendor in _draft.vendors) {
        final key = _quoteCellKey(item.id, vendor.id);
        validKeys.add(key);
        final nextText = _quoteText(
          quoteFor(
            purchaseFile: _draft,
            itemId: item.id,
            vendorId: vendor.id,
          )?.unitPrice,
        );
        final controller = _quoteControllers.putIfAbsent(
          key,
          () => TextEditingController(text: nextText),
        );
        if (controller.text != nextText) {
          controller.value = TextEditingValue(
            text: nextText,
            selection: TextSelection.collapsed(offset: nextText.length),
          );
        }
      }
    }

    final staleKeys = _quoteControllers.keys
        .where((key) => !validKeys.contains(key))
        .toList(growable: false);
    for (final key in staleKeys) {
      _quoteControllers.remove(key)?.dispose();
    }
  }

  TextEditingController _controllerForQuote(String itemId, String vendorId) {
    final key = _quoteCellKey(itemId, vendorId);
    return _quoteControllers.putIfAbsent(
      key,
      () => TextEditingController(
        text: _quoteText(
          quoteFor(
            purchaseFile: _draft,
            itemId: itemId,
            vendorId: vendorId,
          )?.unitPrice,
        ),
      ),
    );
  }

  Future<void> _save() async {
    final resolvedDraft = _resolvedDraft;
    setState(() => _saving = true);
    await ref.read(purchaseFileRepositoryProvider).save(
          resolvedDraft.copyWith(updatedAt: DateTime.now()),
        );
    ref.invalidate(purchaseFilesProvider);
    ref.invalidate(documentsProvider(resolvedDraft.id));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Satın alma dosyası kaydedildi.')),
      );
      setState(() => _saving = false);
    }
  }

  Future<void> _generateDocuments() async {
    final resolvedDraft = _resolvedDraft;
    setState(() => _generating = true);
    await ref.read(purchaseFileRepositoryProvider).save(resolvedDraft);
    await ref.read(documentGenerationServiceProvider).generateDocuments(
          purchaseFile: resolvedDraft,
          settings: widget.settings,
        );
    ref.invalidate(documentsProvider(resolvedDraft.id));
    ref.invalidate(purchaseFilesProvider);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Belge üretim isteği oluşturuldu.')),
      );
      setState(() => _generating = false);
    }
  }

  Future<void> _pickDate({
    required DateTime? initialDate,
    required ValueChanged<DateTime?> onSelected,
  }) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: initialDate ?? now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
      locale: const Locale('tr', 'TR'),
    );
    onSelected(selected);
  }

  void _updateItem(String itemId, PurchaseItem Function(PurchaseItem item) map) {
    setState(() {
      _draft = _draft.copyWith(
        items: _draft.items
            .map((item) => item.id == itemId ? map(item) : item)
            .toList(),
      );
      _syncQuoteControllers();
    });
  }

  void _updateVendor(String vendorId, Vendor Function(Vendor vendor) map) {
    setState(() {
      _draft = _draft.copyWith(
        vendors: _draft.vendors
            .map((vendor) => vendor.id == vendorId ? map(vendor) : vendor)
            .toList(),
      );
      _syncQuoteControllers();
    });
  }

  void _updateQuote(String itemId, String vendorId, String rawValue) {
    setState(() {
      final nextQuotes = [..._draft.quotes];
      final index = nextQuotes.indexWhere(
        (quote) => quote.purchaseItemId == itemId && quote.vendorId == vendorId,
      );
      final price = rawValue.trim().isEmpty ? null : parseDecimal(rawValue);
      if (index == -1) {
        nextQuotes.add(
          VendorQuote.empty(purchaseItemId: itemId, vendorId: vendorId)
              .copyWith(unitPrice: price),
        );
      } else {
        nextQuotes[index] = nextQuotes[index].copyWith(
          unitPrice: price,
          clearPrice: price == null,
        );
      }
      _draft = _draft.copyWith(quotes: nextQuotes);
      _syncQuoteControllers();
    });
  }

  @override
  Widget build(BuildContext context) {
    final lowestTotal = lowestVendorTotal(_draft);
    final quotedVendors = totalQuotedVendorCount(_draft);
    final media = MediaQuery.of(context);
    final isPhoneLandscape =
        media.orientation == Orientation.landscape && media.size.height < 520;

    return DefaultTabController(
      length: 7,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionCard(
            title: _draft.title,
            trailing: FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: _saving
                  ? const SizedBox.square(
                      dimension: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined, size: 18),
              label: const Text('Kaydet'),
              style: isPhoneLandscape
                  ? FilledButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      minimumSize: const Size(96, 36),
                    )
                  : null,
            ),
            child: Wrap(
              spacing: isPhoneLandscape ? 8 : 12,
              runSpacing: isPhoneLandscape ? 8 : 12,
              children: [
                _SummaryChip(
                  label: 'Kalem',
                  value: '${_draft.items.length}',
                  compact: isPhoneLandscape,
                ),
                _SummaryChip(
                  label: 'Teklif veren firma',
                  value: '$quotedVendors / ${_draft.vendors.length}',
                  compact: isPhoneLandscape,
                ),
                _SummaryChip(
                  label: 'En düşük teklif',
                  value: formatCurrency(lowestTotal),
                  compact: isPhoneLandscape,
                ),
              ],
            ),
          ),
          SizedBox(height: isPhoneLandscape ? 8 : 20),
          const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'Genel Bilgiler'),
              Tab(text: 'Ürünler'),
              Tab(text: 'Firmalar'),
              Tab(text: 'Teklifler'),
              Tab(text: 'Onay ve Hesap'),
              Tab(text: 'Muayene'),
              Tab(text: 'Belgeler'),
            ],
          ),
          SizedBox(height: isPhoneLandscape ? 8 : 20),
          Expanded(
            child: TabBarView(
              children: [
                _generalTab(),
                _itemsTab(),
                _vendorsTab(),
                _quotesTab(),
                _approvalTab(lowestTotal),
                _inspectionTab(),
                DocumentsTab(
                  purchaseFileId: _draft.id,
                  onGenerate: _generateDocuments,
                  generating: _generating,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _generalTab() {
    return _wrapTabScrollbar(
      controller: _generalScrollController,
      child: ListView(
        controller: _generalScrollController,
        padding: EdgeInsets.zero,
        children: [
          SectionCard(
            title: 'Genel Bilgiler',
            child: Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                _wideField(
                  label: 'Dosya başlığı',
                  initialValue: _draft.title,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(title: value),
                  ),
                ),
                _wideField(
                  label: 'Belge numarası',
                  initialValue: _draft.documentNumber,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(documentNumber: value),
                  ),
                ),
                _wideField(
                  label: 'Açıklama',
                  initialValue: _draft.description,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(description: value),
                  ),
                ),
                _wideField(
                  label: 'Ekonomik kod',
                  initialValue: _draft.economicCode,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(economicCode: value),
                  ),
                ),
                _dateField(
                  label: 'Talep tarihi',
                  value: _draft.requestDate,
                  onTap: () => _pickDate(
                    initialDate: _draft.requestDate,
                    onSelected: (value) => setState(
                      () => _draft = _draft.copyWith(requestDate: value),
                    ),
                  ),
                ),
                _dateField(
                  label: 'Teklif son tarihi',
                  value: _draft.offerDeadline,
                  onTap: () => _pickDate(
                    initialDate: _draft.offerDeadline,
                    onSelected: (value) => setState(
                      () => _draft = _draft.copyWith(offerDeadline: value),
                    ),
                  ),
                ),
                _dateField(
                  label: 'Onay tarihi',
                  value: _draft.approvalDate,
                  onTap: () => _pickDate(
                    initialDate: _draft.approvalDate,
                    onSelected: (value) => setState(
                      () => _draft = _draft.copyWith(approvalDate: value),
                    ),
                  ),
                ),
                SizedBox(
                  width: _isMobile(context) ? double.infinity : 740,
                  child: TextFormField(
                    initialValue: _draft.notes,
                    minLines: 4,
                    maxLines: 6,
                    decoration: const InputDecoration(labelText: 'Notlar'),
                    onChanged: (value) => setState(
                      () => _draft = _draft.copyWith(notes: value),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _wrapTabScrollbar({
    required ScrollController controller,
    required Widget child,
  }) {
    if (!_isMobile(context)) {
      return child;
    }
    return Scrollbar(
      controller: controller,
      thumbVisibility: true,
      interactive: true,
      child: child,
    );
  }

  Widget _itemsTab() {
    return _wrapTabScrollbar(
      controller: _itemsScrollController,
      child: ListView(
        controller: _itemsScrollController,
        padding: EdgeInsets.zero,
        children: [
          SectionCard(
            title: 'Ürün Satırları',
            trailing: OutlinedButton.icon(
              onPressed: () => setState(
                () => _draft = _draft.copyWith(
                  items: [..._draft.items, PurchaseItem.empty()],
                ),
              ),
              icon: const Icon(Icons.add),
              label: const Text('Satır Ekle'),
            ),
            child: Column(
              children: [
                for (final item in _draft.items) ...[
                  Builder(
                    builder: (context) {
                      final row = Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 4,
                            child: TextFormField(
                              initialValue: item.name,
                              decoration: const InputDecoration(
                                labelText: 'Malzeme adı',
                              ),
                              onChanged: (value) => _updateItem(
                                item.id,
                                (current) => current.copyWith(name: value),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: TextFormField(
                              initialValue: item.quantity.toString(),
                              decoration: const InputDecoration(
                                labelText: 'Miktar',
                              ),
                              onChanged: (value) => _updateItem(
                                item.id,
                                (current) => current.copyWith(
                                  quantity: value.trim().isEmpty
                                      ? 0
                                      : parseDecimal(value),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              initialValue: purchaseUnitOptions.contains(item.unit)
                                  ? item.unit
                                  : 'ADET',
                              decoration: const InputDecoration(
                                labelText: 'Birim',
                              ),
                              isExpanded: true,
                              items: purchaseUnitOptions
                                  .map(
                                    (unit) => DropdownMenuItem<String>(
                                      value: unit,
                                      child: Text(unit),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (value) => _updateItem(
                                item.id,
                                (current) => current.copyWith(
                                  unit: value == null || value.isEmpty
                                      ? 'ADET'
                                      : value,
                                ),
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () => setState(() {
                              _draft = _draft.copyWith(
                                items: _draft.items
                                    .where((current) => current.id != item.id)
                                    .toList(),
                                quotes: _draft.quotes
                                    .where(
                                      (quote) => quote.purchaseItemId != item.id,
                                    )
                                    .toList(),
                              );
                              _syncQuoteControllers();
                            }),
                            icon: const Icon(Icons.delete_outline),
                          ),
                        ],
                      );

                      if (!_isMobile(context)) {
                        return row;
                      }

                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(width: 760, child: row),
                      );
                    },
                  ),
                  if (item != _draft.items.last) const SizedBox(height: 12),
                ],
                if (_draft.items.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('Henüz ürün eklenmedi.'),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _vendorsTab() {
    return _wrapTabScrollbar(
      controller: _vendorsScrollController,
      child: ListView(
        controller: _vendorsScrollController,
        padding: EdgeInsets.zero,
        children: [
          SectionCard(
            title: 'Teklif Alınan Firmalar',
            child: Wrap(
              runSpacing: 16,
              spacing: 16,
              children: _draft.vendors.map((vendor) {
                return SizedBox(
                  width: _isMobile(context) ? double.infinity : 380,
                  child: Column(
                    children: [
                      TextFormField(
                        initialValue: vendor.name,
                        decoration: InputDecoration(
                          labelText: 'Firma ${vendor.slot}',
                        ),
                        onChanged: (value) => _updateVendor(
                          vendor.id,
                          (current) => current.copyWith(name: value),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        initialValue: vendor.contactName,
                        decoration: const InputDecoration(
                          labelText: 'Yetkili kişi',
                        ),
                        onChanged: (value) => _updateVendor(
                          vendor.id,
                          (current) => current.copyWith(contactName: value),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        initialValue: vendor.contactPhone,
                        decoration: const InputDecoration(labelText: 'Telefon'),
                        onChanged: (value) => _updateVendor(
                          vendor.id,
                          (current) => current.copyWith(contactPhone: value),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        initialValue: vendor.contactEmail,
                        decoration: const InputDecoration(labelText: 'E-posta'),
                        onChanged: (value) => _updateVendor(
                          vendor.id,
                          (current) => current.copyWith(contactEmail: value),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _quotesTab() {
    return _wrapTabScrollbar(
      controller: _quotesScrollController,
      child: ListView(
        controller: _quotesScrollController,
        padding: EdgeInsets.zero,
        children: [
          SectionCard(
            title: 'Teklif Tablosu',
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: [
                  const DataColumn(label: Text('Malzeme')),
                  const DataColumn(label: Text('Miktar')),
                  for (final vendor in _draft.vendors)
                    DataColumn(
                      label: Text(vendor.name.isEmpty ? 'Firma' : vendor.name),
                    ),
                ],
                rows: _draft.items.map((item) {
                  return DataRow(
                    cells: [
                      DataCell(SizedBox(width: 260, child: Text(item.name))),
                      DataCell(Text('${item.quantity} ${item.unit}')),
                      for (final vendor in _draft.vendors)
                        DataCell(
                          SizedBox(
                            width: 140,
                            child: TextFormField(
                              key: ValueKey('quote-${item.id}-${vendor.id}'),
                              controller: _controllerForQuote(item.id, vendor.id),
                              decoration: const InputDecoration(
                                labelText: 'Birim fiyat',
                              ),
                              onChanged: (value) =>
                                  _updateQuote(item.id, vendor.id, value),
                            ),
                          ),
                        ),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _approvalTab(double lowestTotal) {
    return _wrapTabScrollbar(
      controller: _approvalScrollController,
      child: ListView(
        controller: _approvalScrollController,
        padding: EdgeInsets.zero,
        children: [
          SectionCard(
            title: 'Onay Bilgileri',
            child: Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                _wideField(
                  label: 'İşin adı',
                  initialValue: _draft.approvalDetails.workName,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails:
                          _draft.approvalDetails.copyWith(workName: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'İşin niteliği',
                  initialValue: _draft.approvalDetails.workNature,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails:
                          _draft.approvalDetails.copyWith(workNature: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Ekonomik kod / bütçe',
                  initialValue: _draft.approvalDetails.budgetCode,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails:
                          _draft.approvalDetails.copyWith(budgetCode: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Usul',
                  initialValue: _draft.approvalDetails.procurementMethod,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails: _draft.approvalDetails
                          .copyWith(procurementMethod: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Teminat',
                  initialValue: _draft.approvalDetails.warrantyTerms,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails:
                          _draft.approvalDetails.copyWith(warrantyTerms: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'İlan',
                  initialValue: _draft.approvalDetails.announcementTerms,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails: _draft.approvalDetails
                          .copyWith(announcementTerms: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Ödeme',
                  initialValue: _draft.approvalDetails.paymentTerms,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      approvalDetails:
                          _draft.approvalDetails.copyWith(paymentTerms: value),
                    ),
                  ),
                ),
                SizedBox(
                  width: _isMobile(context) ? double.infinity : 760,
                  child: TextFormField(
                    initialValue: _draft.approvalDetails.marketResearchText,
                    minLines: 4,
                    maxLines: 6,
                    decoration: const InputDecoration(
                      labelText: 'Piyasa araştırma açıklaması',
                    ),
                    onChanged: (value) => setState(
                      () => _draft = _draft.copyWith(
                        approvalDetails: _draft.approvalDetails
                            .copyWith(marketResearchText: value),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SectionCard(
            title: 'Hesap Özeti',
            child: Column(
              children: [
                for (final vendor in _draft.vendors) ...[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(vendor.name),
                    subtitle: Text(vendor.contactName),
                    trailing: Text(formatCurrency(vendorTotal(_draft, vendor.id))),
                  ),
                ],
                const Divider(),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('En düşük teklif'),
                  trailing: Text(
                    formatCurrency(lowestTotal),
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _inspectionTab() {
    final resolvedInspection = resolvedInspectionDetails(_draft);
    return _wrapTabScrollbar(
      controller: _inspectionScrollController,
      child: ListView(
        controller: _inspectionScrollController,
        padding: EdgeInsets.zero,
        children: [
          SectionCard(
            title: 'Muayene ve Teslim',
            child: Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                _dateField(
                  label: 'Fatura tarihi',
                  value: _draft.inspectionDetails.invoiceDate,
                  onTap: () => _pickDate(
                    initialDate: _draft.inspectionDetails.invoiceDate,
                    onSelected: (value) => setState(
                      () => _draft = _draft.copyWith(
                        inspectionDetails: _draft.inspectionDetails
                            .copyWith(invoiceDate: value),
                      ),
                    ),
                  ),
                ),
                _dateField(
                  label: 'Müzekkere tarihi',
                  value: _draft.inspectionDetails.dispatchDate,
                  onTap: () => _pickDate(
                    initialDate: _draft.inspectionDetails.dispatchDate,
                    onSelected: (value) => setState(
                      () => _draft = _draft.copyWith(
                        inspectionDetails: _draft.inspectionDetails
                            .copyWith(dispatchDate: value),
                      ),
                    ),
                  ),
                ),
                _wideField(
                  fieldKey: ValueKey(
                    'inspection-seller-${resolvedInspection.sellerCompanyName}',
                  ),
                  label: 'Satan firma',
                  initialValue: resolvedInspection.sellerCompanyName,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      inspectionDetails: _draft.inspectionDetails
                          .copyWith(sellerCompanyName: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Ödeme emri',
                  initialValue: _draft.inspectionDetails.paymentOrderNumber,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      inspectionDetails: _draft.inspectionDetails
                          .copyWith(paymentOrderNumber: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Teslim eden',
                  initialValue: _draft.inspectionDetails.deliveredBy,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      inspectionDetails:
                          _draft.inspectionDetails.copyWith(deliveredBy: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'Depo / teslim yeri',
                  initialValue: _draft.inspectionDetails.warehouseLocation,
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      inspectionDetails: _draft.inspectionDetails
                          .copyWith(warehouseLocation: value),
                    ),
                  ),
                ),
                _wideField(
                  label: 'KDV hariç fatura',
                fieldKey: ValueKey(
                  'inspection-excluding-${_quoteText(resolvedInspection.invoiceAmountExcludingVat)}',
                ),
                initialValue: _quoteText(
                  resolvedInspection.invoiceAmountExcludingVat,
                ),
                onChanged: (value) => setState(
                  () => _draft = _draft.copyWith(
                    inspectionDetails: _draft.inspectionDetails.copyWith(
                      invoiceAmountExcludingVat:
                          value.trim().isEmpty ? null : parseDecimal(value),
                    ),
                  ),
                ),
              ),
              _wideField(
                label: 'KDV dahil fatura',
                fieldKey: ValueKey(
                  'inspection-including-${_quoteText(resolvedInspection.invoiceAmountIncludingVat)}',
                ),
                initialValue: _quoteText(
                  resolvedInspection.invoiceAmountIncludingVat,
                ),
                onChanged: (value) => setState(
                  () => _draft = _draft.copyWith(
                    inspectionDetails: _draft.inspectionDetails.copyWith(
                      invoiceAmountIncludingVat:
                          value.trim().isEmpty ? null : parseDecimal(value),
                    ),
                  ),
                ),
              ),
              _wideField(
                label: 'Damga vergisi oranı',
                initialValue:
                    _draft.inspectionDetails.stampTaxRate.toStringAsFixed(5),
                onChanged: (value) => setState(
                  () => _draft = _draft.copyWith(
                    inspectionDetails: _draft.inspectionDetails.copyWith(
                      stampTaxRate:
                          value.trim().isEmpty ? 0 : parseDecimal(value),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: _isMobile(context) ? double.infinity : 760,
                child: TextFormField(
                  initialValue: _draft.inspectionDetails.notes,
                  minLines: 4,
                  maxLines: 6,
                  decoration:
                      const InputDecoration(labelText: 'Muayene notları'),
                  onChanged: (value) => setState(
                    () => _draft = _draft.copyWith(
                      inspectionDetails:
                          _draft.inspectionDetails.copyWith(notes: value),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
      ),
    );
  }

  Widget _wideField({
    Key? fieldKey,
    required String label,
    required String initialValue,
    required ValueChanged<String> onChanged,
  }) {
    return SizedBox(
      width: _isMobile(context) ? double.infinity : 360,
      child: TextFormField(
        key: fieldKey,
        initialValue: initialValue,
        decoration: InputDecoration(labelText: label),
        onChanged: onChanged,
      ),
    );
  }

  Widget _dateField({
    required String label,
    required DateTime? value,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: _isMobile(context) ? double.infinity : 220,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: InputDecorator(
          decoration: InputDecoration(labelText: label),
          child: Text(formatDate(value)),
        ),
      ),
    );
  }

  bool _isMobile(BuildContext context) =>
      MediaQuery.of(context).size.width < _mobileBreakpoint;
}

class _SummaryChip extends StatelessWidget {
  const _SummaryChip({
    required this.label,
    required this.value,
    this.compact = false,
  });

  final String label;
  final String value;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16, vertical: compact ? 8 : 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label),
          SizedBox(height: compact ? 2 : 4),
          Text(
            value,
            style: compact ? Theme.of(context).textTheme.titleSmall : Theme.of(context).textTheme.titleMedium,
          ),
        ],
      ),
    );
  }
}

