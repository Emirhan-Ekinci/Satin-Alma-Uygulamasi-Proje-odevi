import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/core/utils/formatters.dart';
import 'package:satin_alma_evrak/features/purchase_files/application/purchase_providers.dart';
import 'package:satin_alma_evrak/features/purchase_files/data/purchase_file_repository.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';
import 'package:satin_alma_evrak/features/purchase_files/presentation/purchase_editor.dart';
import 'package:satin_alma_evrak/features/settings/domain/organization_settings.dart';
import 'package:satin_alma_evrak/shared/widgets/section_card.dart';

class PurchaseWorkspaceScreen extends ConsumerWidget {
  const PurchaseWorkspaceScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filesAsync = ref.watch(purchaseFilesProvider);
    final settingsAsync = ref.watch(organizationSettingsProvider);
    final selectedId = ref.watch(selectedPurchaseFileIdProvider);

    return filesAsync.when(
      data: (files) {
        return LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 1100;
            final selected = files.where((file) => file.id == selectedId);
            final selectedFile = selected.isEmpty ? null : selected.first;
            final currentFile =
                selectedFile ?? (files.isEmpty ? null : files.first);

            final listPanel = _FileListPanel(
              files: files,
              selectedId: compact ? null : currentFile?.id,
              onCreate: () async {
                  try {
                    final settings = settingsAsync.valueOrNull ?? OrganizationSettings.demo();
                    final created = await ref
                        .read(purchaseFileRepositoryProvider)
                        .createFromSettings(settings);
                    ref.invalidate(purchaseFilesProvider);
                    ref.read(selectedPurchaseFileIdProvider.notifier).state =
                        created.id;

                    if (compact && context.mounted) {
                      await Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (context) => _MobileEditorPage(
                            file: created,
                            settings: settings,
                          ),
                        ),
                      );
                      ref.invalidate(purchaseFilesProvider);
                    }
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Hata oluştu: ${e.toString()}'),
                          backgroundColor: Theme.of(context).colorScheme.error,
                        ),
                      );
                    }
                  }
                },
              onSelect: (id) async {
                ref.read(selectedPurchaseFileIdProvider.notifier).state = id;
                if (!compact) {
                  return;
                }

                final tappedFile = files.firstWhere((file) => file.id == id);
                final settings = await ref.read(
                  organizationSettingsProvider.future,
                );
                if (!context.mounted) {
                  return;
                }

                await Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (context) => _MobileEditorPage(
                      file: tappedFile,
                      settings: settings,
                    ),
                  ),
                );
                ref.invalidate(purchaseFilesProvider);
              },
              onDelete: (id) async {
                try {
                  await ref.read(purchaseFileRepositoryProvider).delete(id);
                  ref.invalidate(purchaseFilesProvider);
                  if (selectedId == id) {
                    ref.read(selectedPurchaseFileIdProvider.notifier).state = null;
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Hata oluştu: ${e.toString()}'),
                        backgroundColor: Theme.of(context).colorScheme.error,
                      ),
                    );
                  }
                }
              },
            );

            final detail = currentFile == null
                ? const _EmptyWorkspace()
                : settingsAsync.when(
                    data: (settings) => PurchaseEditor(
                      key: ValueKey(currentFile.id),
                      initialValue: currentFile,
                      settings: settings,
                    ),
                    loading: () =>
                        const Center(child: CircularProgressIndicator()),
                    error: (error, stackTrace) => Center(
                      child: Text(error.toString()),
                    ),
                  );

            if (compact) {
              return Padding(
                padding: const EdgeInsets.all(24),
                child: SingleChildScrollView(child: listPanel),
              );
            }

            return Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(width: 340, child: listPanel),
                  const SizedBox(width: 24),
                  Expanded(child: detail),
                ],
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) => Center(child: Text(error.toString())),
    );
  }
}

class _FileListPanel extends StatelessWidget {
  const _FileListPanel({
    required this.files,
    required this.selectedId,
    required this.onCreate,
    required this.onSelect,
    required this.onDelete,
  });

  final List<PurchaseFile> files;
  final String? selectedId;
  final Future<void> Function()? onCreate;
  final ValueChanged<String> onSelect;
  final Future<void> Function(String id) onDelete;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Dosyalar',
      trailing: FilledButton.icon(
        onPressed: onCreate,
        icon: const Icon(Icons.add),
        label: const Text('Yeni'),
      ),
      child: Column(
        children: [
          for (final file in files) ...[
            Material(
              color: selectedId == file.id
                  ? Theme.of(context).colorScheme.secondaryContainer
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(18),
              child: ListTile(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
                title: Text(file.title),
                subtitle: Text(
                  '${formatDate(file.requestDate)} • ${file.items.length} kalem',
                ),
                onTap: () => onSelect(file.id),
                trailing: IconButton(
                  onPressed: () => onDelete(file.id),
                  icon: const Icon(Icons.delete_outline),
                ),
              ),
            ),
            if (file != files.last) const SizedBox(height: 8),
          ],
          if (files.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text('Henüz satın alma dosyası yok.'),
            ),
        ],
      ),
    );
  }
}

class _EmptyWorkspace extends StatelessWidget {
  const _EmptyWorkspace();

  @override
  Widget build(BuildContext context) {
    return const SectionCard(
      title: 'Hazır',
      child: Text('Yeni bir satın alma dosyası oluşturarak başlayabilirsin.'),
    );
  }
}

class _MobileEditorPage extends StatelessWidget {
  const _MobileEditorPage({
    required this.file,
    required this.settings,
  });

  final PurchaseFile file;
  final OrganizationSettings settings;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Satın Alma Dosyası')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: PurchaseEditor(
          key: ValueKey(file.id),
          initialValue: file,
          settings: settings,
        ),
      ),
    );
  }
}
