﻿import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:satin_alma_evrak/app/theme.dart';
import 'package:satin_alma_evrak/features/auth/data/auth_service.dart';
import 'package:satin_alma_evrak/features/auth/presentation/login_screen.dart';
import 'package:satin_alma_evrak/features/purchase_files/application/purchase_providers.dart';
import 'package:satin_alma_evrak/features/purchase_files/presentation/purchase_workspace_screen.dart';
import 'package:satin_alma_evrak/features/settings/presentation/settings_screen.dart';

class ProcurementApp extends ConsumerWidget {
  const ProcurementApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'Satın Alma Evrak',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      locale: const Locale('tr', 'TR'),
      supportedLocales: const [Locale('tr', 'TR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const AppRoot(),
    );
  }
}

class AppRoot extends ConsumerWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (ref.watch(isDemoModeProvider)) {
      return const AppShell();
    }

    final authState = ref.watch(authStateProvider);
    return authState.when(
      data: (user) => user == null ? const LoginScreen() : const AppShell(),
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (error, stackTrace) => Scaffold(
        body: Center(child: Text(error.toString())),
      ),
    );
  }
}

class AppShell extends ConsumerWidget {
  const AppShell({super.key});

  static const _pages = [
    ('Satın Alma Dosyaları', Icons.inventory_2_outlined),
    ('Kurum Ayarları', Icons.apartment_outlined),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = ref.watch(shellIndexProvider);
    final isDemoMode = ref.watch(isDemoModeProvider);
    final currentUser = ref.watch(authStateProvider).valueOrNull;
    final page = switch (index) {
      0 => const PurchaseWorkspaceScreen(),
      _ => const SettingsScreen(),
    };

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 1024;
        return Scaffold(
          appBar: AppBar(
            title: Text(_pages[index].$1),
            actions: [
              if (isDemoMode)
                Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: const Center(child: Text('Demo mod')),
                ),
              if (!isDemoMode)
                IconButton(
                  tooltip: currentUser?.email.isNotEmpty == true
                      ? '${currentUser!.email} oturumunu kapat'
                      : 'Oturumu kapat',
                  onPressed: () async {
                    ref.invalidate(purchaseFilesProvider);
                    ref.invalidate(organizationSettingsProvider);
                    ref.invalidate(selectedPurchaseFileIdProvider);
                    ref.invalidate(shellIndexProvider);
                    await ref.read(authServiceProvider).signOut();
                  },
                  icon: const Icon(Icons.logout),
                ),
            ],
          ),
          drawer: compact
              ? Drawer(
                  child: SafeArea(
                    child: Column(
                      children: [
                        const ListTile(
                          title: Text('Satın Alma Evrak'),
                          subtitle: Text('Windows + Web çalışma alanı'),
                        ),
                        for (var i = 0; i < _pages.length; i++)
                          ListTile(
                            leading: Icon(_pages[i].$2),
                            title: Text(_pages[i].$1),
                            selected: i == index,
                            onTap: () {
                              ref.read(shellIndexProvider.notifier).state = i;
                              Navigator.of(context).pop();
                            },
                          ),
                      ],
                    ),
                  ),
                )
              : null,
          body: Row(
            children: [
              if (!compact)
                NavigationRail(
                  selectedIndex: index,
                  onDestinationSelected: (value) =>
                      ref.read(shellIndexProvider.notifier).state = value,
                  labelType: NavigationRailLabelType.all,
                  destinations: [
                    for (final page in _pages)
                      NavigationRailDestination(
                        icon: Icon(page.$2),
                        label: Text(page.$1),
                      ),
                  ],
                ),
              Expanded(child: page),
            ],
          ),
        );
      },
    );
  }
}
