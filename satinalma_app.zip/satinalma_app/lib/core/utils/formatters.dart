import 'package:intl/intl.dart';

final NumberFormat currencyFormatter = NumberFormat.currency(
  locale: 'tr_TR',
  symbol: 'TL',
  decimalDigits: 2,
);

final NumberFormat decimalFormatter = NumberFormat.decimalPattern('tr_TR');
final DateFormat shortDateFormatter = DateFormat('dd.MM.yyyy', 'tr_TR');

String formatCurrency(double value) => currencyFormatter.format(value);

String formatDate(DateTime? value) {
  if (value == null) {
    return '-';
  }
  return shortDateFormatter.format(value);
}

double parseDecimal(String raw) {
  final normalized = raw.trim().replaceAll('.', '').replaceAll(',', '.');
  return double.tryParse(normalized) ?? 0;
}
