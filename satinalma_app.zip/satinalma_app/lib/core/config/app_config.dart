import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AppConfig {
  const AppConfig({
    required this.firebaseApiKey,
    required this.firebaseProjectId,
    required this.firebaseMessagingSenderId,
    required this.firebaseAuthDomain,
    required this.firebaseStorageBucket,
    required this.firebaseMeasurementId,
    required this.firebaseWebAppId,
    required this.firebaseWindowsAppId,
    required this.firebaseAndroidAppId,
  });

  factory AppConfig.fromEnvironment() {
    return const AppConfig(
      firebaseApiKey: 'AIzaSyAtyt9iSej7PCeHU0caTI7LD_A2tBl0Q8w',
      firebaseProjectId: 'fluttersatinalmaapp',
      firebaseMessagingSenderId: '965459791958',
      firebaseAuthDomain: 'fluttersatinalmaapp.firebaseapp.com',
      firebaseStorageBucket: 'fluttersatinalmaapp.firebasestorage.app',
      firebaseMeasurementId: 'G-7CB9WZ2TF0',
      firebaseWebAppId: '1:965459791958:web:ac1dcc5e8add300e6cebf7',
      firebaseWindowsAppId: '1:965459791958:web:ac1dcc5e8add300e6cebf7', // Fallback to Web ID
      firebaseAndroidAppId: '1:965459791958:android:4a73e8f3cd24c6656cebf7',
    );
  }

  final String firebaseApiKey;
  final String firebaseProjectId;
  final String firebaseMessagingSenderId;
  final String firebaseAuthDomain;
  final String firebaseStorageBucket;
  final String firebaseMeasurementId;
  final String firebaseWebAppId;
  final String firebaseWindowsAppId;
  final String firebaseAndroidAppId;

  bool get _hasCoreFirebaseConfig =>
      firebaseApiKey.trim().isNotEmpty &&
      firebaseProjectId.trim().isNotEmpty &&
      firebaseMessagingSenderId.trim().isNotEmpty;

  bool get useFirebase {
    if (!_hasCoreFirebaseConfig) {
      debugPrint('Firebase: Core configuration missing (API Key, Project ID, or Sender ID).');
      return false;
    }
    if (kIsWeb) {
      final hasWebId = firebaseWebAppId.trim().isNotEmpty;
      if (!hasWebId) {
        debugPrint('Firebase: Web App ID missing.');
      }
      return hasWebId;
    }
    final hasWindowsId = firebaseWindowsAppId.trim().isNotEmpty;
    final hasAndroidId = firebaseAndroidAppId.trim().isNotEmpty;
    if (!hasWindowsId && defaultTargetPlatform == TargetPlatform.windows) {
      debugPrint('Firebase: Windows App ID missing.');
    }
    if (!hasAndroidId && defaultTargetPlatform == TargetPlatform.android) {
      debugPrint('Firebase: Android App ID missing.');
    }
    return switch (defaultTargetPlatform) {
      TargetPlatform.windows => hasWindowsId,
      TargetPlatform.android => hasAndroidId,
      _ => false,
    };
  }
}

final appConfigProvider = Provider<AppConfig>(
  (ref) => throw UnimplementedError('AppConfig override edilmedi.'),
);
