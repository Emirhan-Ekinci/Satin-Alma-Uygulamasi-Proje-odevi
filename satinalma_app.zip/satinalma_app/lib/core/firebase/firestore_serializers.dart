import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satin_alma_evrak/features/documents/domain/generated_document.dart';
import 'package:satin_alma_evrak/features/purchase_files/domain/purchase_models.dart';

class FirestoreSerializers {
  static Map<String, dynamic> purchaseFileToFirestore(PurchaseFile file) {
    final json = Map<String, dynamic>.from(file.toJson());
    json['request_date'] = _toTimestamp(file.requestDate);
    json['offer_deadline'] = _toTimestamp(file.offerDeadline);
    json['approval_date'] = _toTimestamp(file.approvalDate);
    json['created_at'] = Timestamp.fromDate(file.createdAt);
    json['updated_at'] = Timestamp.fromDate(file.updatedAt);

    final inspection = Map<String, dynamic>.from(
      json['inspection_details'] as Map<String, dynamic>,
    );
    inspection['invoice_date'] = _toTimestamp(file.inspectionDetails.invoiceDate);
    inspection['dispatch_date'] = _toTimestamp(
      file.inspectionDetails.dispatchDate,
    );
    json['inspection_details'] = inspection;

    return json;
  }

  static Map<String, dynamic> purchaseFileFromFirestore(
    Map<String, dynamic> data,
  ) {
    final json = Map<String, dynamic>.from(data);
    json['request_date'] = _toIsoString(data['request_date']);
    json['offer_deadline'] = _toIsoString(data['offer_deadline']);
    json['approval_date'] = _toIsoString(data['approval_date']);
    json['created_at'] = _toIsoString(data['created_at']);
    json['updated_at'] = _toIsoString(data['updated_at']);

    final inspectionSource = Map<String, dynamic>.from(
      (data['inspection_details'] as Map?) ?? const <String, dynamic>{},
    );
    inspectionSource['invoice_date'] = _toIsoString(
      inspectionSource['invoice_date'],
    );
    inspectionSource['dispatch_date'] = _toIsoString(
      inspectionSource['dispatch_date'],
    );
    json['inspection_details'] = inspectionSource;

    return json;
  }

  static Map<String, dynamic> generatedDocumentToFirestore(
    GeneratedDocument document,
  ) {
    final json = Map<String, dynamic>.from(document.toJson());
    json['created_at'] = Timestamp.fromDate(document.createdAt);
    return json;
  }

  static Map<String, dynamic> generatedDocumentFromFirestore(
    Map<String, dynamic> data,
  ) {
    final json = Map<String, dynamic>.from(data);
    json['created_at'] = _toIsoString(data['created_at']);
    return json;
  }

  static Timestamp? _toTimestamp(DateTime? value) {
    if (value == null) {
      return null;
    }
    return Timestamp.fromDate(value);
  }

  static String? _toIsoString(dynamic value) {
    if (value == null) {
      return null;
    }
    if (value is Timestamp) {
      return value.toDate().toIso8601String();
    }
    if (value is DateTime) {
      return value.toIso8601String();
    }
    return value.toString();
  }
}
