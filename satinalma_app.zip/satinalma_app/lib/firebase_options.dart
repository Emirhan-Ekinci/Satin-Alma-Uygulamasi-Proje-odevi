import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show TargetPlatform, defaultTargetPlatform, kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.android:
      case TargetPlatform.iOS:
      case TargetPlatform.linux:
      case TargetPlatform.macOS:
      case TargetPlatform.fuchsia:
        return android;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAtyt9iSej7PCeHU0caTI7LD_A2tBl0Q8w',
    appId: '1:965459791958:web:ac1dcc5e8add300e6cebf7',
    messagingSenderId: '965459791958',
    projectId: 'fluttersatinalmaapp',
    authDomain: 'fluttersatinalmaapp.firebaseapp.com',
    storageBucket: 'fluttersatinalmaapp.firebasestorage.app',
    measurementId: 'G-7CB9WZ2TF0',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyAtyt9iSej7PCeHU0caTI7LD_A2tBl0Q8w',
    appId: '1:965459791958:web:ac1dcc5e8add300e6cebf7', // Web ID used for Windows fallback
    messagingSenderId: '965459791958',
    projectId: 'fluttersatinalmaapp',
    authDomain: 'fluttersatinalmaapp.firebaseapp.com',
    storageBucket: 'fluttersatinalmaapp.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBQ8oAlsy5vYVGhRgQY0iKc2lNnwr6C-3c',
    appId: '1:965459791958:android:4a73e8f3cd24c6656cebf7',
    messagingSenderId: '965459791958',
    projectId: 'fluttersatinalmaapp',
    storageBucket: 'fluttersatinalmaapp.firebasestorage.app',
  );

}